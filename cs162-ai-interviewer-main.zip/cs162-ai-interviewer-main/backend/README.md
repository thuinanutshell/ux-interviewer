# README

## How to Run the Backend Flask App

### 1. Navigate to the Backend Directory

Change into the `backend` directory:
```bash
cd backend
```

### 2. Set Up the Virtual Environment

Create a virtual environment:
```bash
python3 -m venv venv
```

Activate the virtual environment:
- On macOS/Linux:
  ```bash
  source venv/bin/activate
  ```
- On Windows:
  ```bash
  venv\Scripts\activate
  ```

### 3. Install the Requirements

Install the necessary dependencies by running:
```bash
pip install -r requirements.txt
```

### 4. Run the Flask Application

Run the Flask application using one of the following methods:

- Execute the Python script directly:
  ```bash
  python3 run.py
  ```

- Use the Flask CLI:
  ```bash
  flask --app api run
  ```

### 5. Access the App

The app will start, and the server will be accessible at `http://127.0.0.1:5000` by default.
