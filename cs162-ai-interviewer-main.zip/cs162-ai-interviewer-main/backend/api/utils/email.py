# api/utils/email.py

import os
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail, ReplyTo
from flask import current_app, url_for
from typing import Optional, List, Dict

class EmailService:
    """
    A streamlined email service using SendGrid for handling all email communications.
    This service provides a simple interface while maintaining reliability and error tracking.
    """
    
    def __init__(self, app=None):
        """
        Initialize the email service with an optional Flask application.
        The service can be initialized later using init_app if the app isn't available at creation time.
        """
        self.app = app
        self.client = None
        if app is not None:
            self.init_app(app)

    def init_app(self, app):
        """
        Configure the email service with a Flask application instance.
        This sets up the SendGrid client and loads necessary configuration settings.
        """
        self.app = app
        # Initialize SendGrid client with API key from environment variables
        self.client = SendGridAPIClient(os.environ.get('SENDGRID_API_KEY'))
        # Store the verified sender email from configuration
        self.sender_email = app.config.get('SENDER_EMAIL', 'your-verified@email.com')

    def send_email(
        self,
        to_email: str,
        subject: str,
        html_content: str,
        reply_to: Optional[str] = None
    ) -> bool:
        """
        Send an email to a single recipient using SendGrid.
        
        Args:
            to_email: The recipient's email address
            subject: The email subject line
            html_content: The HTML content of the email
            reply_to: Optional reply-to email address
        
        Returns:
            bool: True if the email was sent successfully, False otherwise
        """
        try:
            # Create the email message with required fields
            message = Mail(
                from_email=self.sender_email,
                to_emails=to_email,
                subject=subject,
                html_content=html_content
            )
            
            # Add reply-to address if provided
            if reply_to:
                message.reply_to = ReplyTo(reply_to)
            
            # Send the email and check response
            response = self.client.send(message)
            
            # Log success or failure
            if response.status_code in [200, 201, 202]:
                current_app.logger.info(f"Email sent successfully to {to_email}")
                return True
            else:
                current_app.logger.error(
                    f"Failed to send email to {to_email}. Status code: {response.status_code}"
                )
                return False
                
        except Exception as e:
            current_app.logger.error(f"Error sending email to {to_email}: {str(e)}")
            return False
        
    def send_verification_email(self, user_email: str, verification_token: str) -> bool:
        """
        Send an email verification token to a user.
        
        Args:
            user_email: The recipient's email address
            verification_token: The verification token to include in the email
        
        Returns:
            bool: True if the email was sent successfully, False otherwise
        """
        verification_url = url_for('auth.verify_email', 
                                token=verification_token, 
                                _external=True)
        
        html_content = f"""
        <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
            <h2>Verify Your Email Address</h2>
            <p>Please click the button below to verify your email address:</p>
            <a href="{verification_url}" 
            style="display: inline-block; padding: 10px 20px; 
                    background-color: #007bff; color: white; 
                    text-decoration: none; border-radius: 5px;">
                Verify Email
            </a>
            <p>Or copy and paste this link into your browser:</p>
            <p>{verification_url}</p>
            <p>This verification link will expire in 24 hours.</p>
            <p>If you didn't create an account, please ignore this email.</p>
            <p>For help, contact us at {current_app.config.get('SUPPORT_EMAIL')}</p>
        </div>
        """
        
        return self.send_email(
            to_email=user_email,
            subject="Verify Your Email Address",
            html_content=html_content
        )
    
    # backend/api/utils/email.py

    def send_batch_interview_invitations(self, invitations: List[Dict]) -> Dict[str, bool]:
        """Send interview invitation emails to multiple participants."""
        results = {}
        
        try:
            for invitation in invitations:
                try:
                    interview_url = url_for('interview_bp.participate',
                                        token=invitation['invitation_token'],
                                        _external=True)
                    
                    html_content = f"""
                    <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                        <h2>You're Invited to Participate in a Product Interview</h2>
                        <p>We would like to invite you to participate in an interview about {invitation['interview_title']}.</p>
                        <div style="margin: 30px 0;">
                            <a href="{interview_url}" 
                            style="background-color: #4F46E5; color: white; 
                                    padding: 12px 24px; text-decoration: none; 
                                    border-radius: 6px; display: inline-block;">
                                Start Interview
                            </a>
                        </div>
                        <p>This link is unique to you and will expire in 7 days.</p>
                        <p>If you cannot click the button, copy and paste this link into your browser:</p>
                        <p>{interview_url}</p>
                    </div>
                    """
                    
                    message = Mail(
                        from_email=self.sender_email,
                        to_emails=invitation['email'],
                        subject=f"Invitation to Participate: {invitation['interview_title']}",
                        html_content=html_content
                    )
                    
                    response = self.client.send(message)
                    results[invitation['email']] = response.status_code in [200, 201, 202]
                    
                    if results[invitation['email']]:
                        current_app.logger.info(f"Successfully sent invitation to {invitation['email']}")
                    else:
                        current_app.logger.warning(f"Failed to send invitation to {invitation['email']}")
                        
                except Exception as e:
                    current_app.logger.error(f"Error sending invitation to {invitation['email']}: {str(e)}")
                    results[invitation['email']] = False
                    
            return results
            
        except Exception as e:
            current_app.logger.error(f"Error in batch email sending: {str(e)}")
            return {invitation['email']: False for invitation in invitations}
            
    def send_password_reset_email(self, user_email: str, reset_token: str) -> bool:
        """Send a password reset email to the user."""
        reset_url = url_for('auth.reset_password',
                           token=reset_token,
                           _external=True)
        
        html_content = f"""
        <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
            <h2>Reset Your Password</h2>
            <p>Click the button below to reset your password:</p>
            <a href="{reset_url}" 
               style="display: inline-block; padding: 10px 20px; 
                      background-color: #007bff; color: white; 
                      text-decoration: none; border-radius: 5px;">
                Reset Password
            </a>
            <p>Or copy and paste this link into your browser:</p>
            <p>{reset_url}</p>
            <p>This reset link will expire in 24 hours.</p>
            <p>If you didn't request this reset, please ignore this email.</p>
        </div>
        """
        
        return self.send_email(
            to_email=user_email,
            subject="Reset Your Password",
            html_content=html_content
        )

