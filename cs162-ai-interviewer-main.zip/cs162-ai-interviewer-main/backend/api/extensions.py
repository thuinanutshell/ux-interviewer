# backend/api/extensions.py

from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_jwt_extended import JWTManager
from flask_marshmallow import Marshmallow
from flask_cors import CORS
from authlib.integrations.flask_client import OAuth

# Database and migrations
db = SQLAlchemy()
migrate = Migrate()

# JWT for authentication
jwt = JWTManager()

# Marshmallow for serialization/deserialization
ma = Marshmallow()

# CORS for cross-origin requests
cors = CORS()

# OAuth for third-party authentication
oauth = OAuth()