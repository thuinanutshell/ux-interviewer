from sqlalchemy import ForeignKey, String, Text, DateTime, LargeBinary
from datetime import datetime, timezone
from api.models.base import BaseModel, db
from api.models.interviews import Question, Participant

class Response(BaseModel):
    participant_id = db.Column(String(36), ForeignKey(f'{Participant.__tablename__}.participant_id'), primary_key=True)
    question_id = db.Column(String(36), ForeignKey(f'{Question.__tablename__}.question_id'), primary_key=True)
    # audio = db.Column(LargeBinary, nullable=True)
    response_text = db.Column(Text, nullable=True)
    completed_at = db.Column(DateTime, nullable=True, default=lambda: datetime.now(timezone.utc))
