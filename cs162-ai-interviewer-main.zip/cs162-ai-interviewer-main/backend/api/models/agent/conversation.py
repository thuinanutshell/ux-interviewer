# backend/api/models/conversation.py
from datetime import datetime
from api.models.base import BaseModel
from api.extensions import db
import uuid

class Conversation(BaseModel):
    """Model for storing interview conversations with follow-up tracking."""
    
    conversation_id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    interview_id = db.Column(db.String(36), db.ForeignKey('interviews.interview_id', ondelete='CASCADE'), nullable=False)
    user_input = db.Column(db.Text, nullable=False)
    agent_response = db.Column(db.Text, nullable=False)
    is_follow_up = db.Column(db.Boolean, default=False)
    follow_up_sequence = db.Column(db.Integer, default=0)  # 0 for initial response, 1 or 2 for follow-ups
    created_at = db.Column(db.String(64), nullable=False, default=lambda: datetime.utcnow().isoformat())

    def to_dict(self):
        """Convert model instance to dictionary."""
        return {
            'conversation_id': self.conversation_id,
            'interview_id': self.interview_id,
            'user_input': self.user_input,
            'agent_response': self.agent_response,
            'is_follow_up': self.is_follow_up,
            'follow_up_sequence': self.follow_up_sequence,
            'created_at': self.created_at
        }