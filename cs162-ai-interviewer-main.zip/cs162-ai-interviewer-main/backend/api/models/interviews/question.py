from sqlalchemy import ForeignKey, String, Text, DateTime
from datetime import datetime
from api.models.base import BaseModel, db
from api.models.interviews import Interview

class Question(BaseModel):
    question_id = db.Column(String(36), primary_key=True)
    interview_id = db.Column(String(36), ForeignKey(f'{Interview.__tablename__}.interview_id'), nullable=False, index=True)
    question = db.Column(Text, nullable=False)
    created_at = db.Column(DateTime, default=datetime.utcnow, nullable=False)
