from sqlalchemy import ForeignKey, String, DateTime
from datetime import datetime, timezone
from api.models.base import BaseModel, db
from api.models.interviews import Interview

class Participant(BaseModel):
    participant_id = db.Column(String(36), primary_key=True)
    email = db.Column(String(255), nullable=False, unique=True, index=True)
    profession = db.Column(String(255), nullable=True)
    interview_id = db.Column(String(36), ForeignKey(f'{Interview.__tablename__}.interview_id'), index=True)
    created_at = db.Column(DateTime, nullable=False, default=lambda: datetime.now(timezone.utc))
