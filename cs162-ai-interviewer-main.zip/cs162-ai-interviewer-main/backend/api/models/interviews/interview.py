from sqlalchemy import ForeignKey, String, Text
from api.models.base import BaseModel, db
from api.models.users import User
from api.models.products import Product

class Interview(BaseModel):
    interview_id = db.Column(String(36), primary_key=True)
    creator = db.Column(String(36), ForeignKey(f'{User.__tablename__}.user_id'), nullable=False)
    product_id = db.Column(String(36), ForeignKey(f'{Product.__tablename__}.product_id'), nullable=False)
    title = db.Column(String(255), nullable=False)
    description = db.Column(Text, nullable=True)
    
