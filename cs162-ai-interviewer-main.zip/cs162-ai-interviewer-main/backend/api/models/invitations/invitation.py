from sqlalchemy import ForeignKey, String, DateTime
from datetime import datetime, timezone
from api.models.base import BaseModel, db
from api.models.interviews import Participant, Interview

class Invitation(BaseModel):
    participant_id = db.Column(String(36), ForeignKey(f'{Participant.__tablename__}.participant_id'), primary_key=True)
    interview_id = db.Column(String(36), ForeignKey(f'{Interview.__tablename__}.interview_id'), primary_key=True)
    invitation_token = db.Column(String(255), nullable=False)
    created_at = db.Column(DateTime, nullable=False, default=lambda: datetime.now(timezone.utc))
    expires_at = db.Column(DateTime, nullable=False)
