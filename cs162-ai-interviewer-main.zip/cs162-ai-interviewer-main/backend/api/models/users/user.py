# backend/api/models/users/user.py

from datetime import datetime, timezone
from typing import Optional
from api.extensions import db
from api.models.base import BaseModel
from werkzeug.security import generate_password_hash, check_password_hash
import logging
from itsdangerous import URLSafeTimedSerializer, SignatureExpired, BadSignature
from flask import current_app

logger = logging.getLogger(__name__)

class User(BaseModel):
    """
    User Model for storing authentication and user account information.
    Inherits from BaseModel to maintain consistent table naming and base functionality.
    """
    # Primary identification fields
    user_id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False, index=True)
    email = db.Column(db.String(150), unique=True, nullable=False, index=True)
    
    # Authentication fields
    password_hash = db.Column(db.String(150), nullable=True)
    is_oauth_user = db.Column(db.Boolean, default=False)
    
    # Timestamp fields
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    last_login = db.Column(db.DateTime, nullable=True)
    
    # Account status fields
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    is_verified = db.Column(db.Boolean, default=False, nullable=False)

    email_verified_at = db.Column(db.DateTime, nullable=True)

    def generate_verification_token(self) -> str:
        """
        Generate a secure token for email verification.
        
        Returns:
            str: A secure URL-safe token containing encrypted user email
        """
        try:
            serializer = URLSafeTimedSerializer(current_app.config['SECRET_KEY'])
            return serializer.dumps(self.email, salt='email-verification')
        except Exception as e:
            current_app.logger.error(f"Error generating verification token for user {self.email}: {str(e)}")
            raise

    @staticmethod
    def verify_email_token(token: str, expiration: int = 86400) -> Optional['User']:
        """
        Verify the email verification token and return the associated user.
        
        Args:
            token: The verification token
            expiration: Token expiration time in seconds (default 24 hours)
            
        Returns:
            Optional[User]: The user associated with the token if valid, None otherwise
        """
        try:
            serializer = URLSafeTimedSerializer(current_app.config['SECRET_KEY'])
            email = serializer.loads(token, salt='email-verification', max_age=expiration)
            return User.query.filter_by(email=email).first()
        except (SignatureExpired, BadSignature) as e:
            current_app.logger.warning(f"Invalid or expired verification token: {str(e)}")
            return None
        except Exception as e:
            current_app.logger.error(f"Error verifying email token: {str(e)}")
            return None
        
    def set_password(self, password: str) -> None:
        """
        Set a secure password hash for the user.
        Uses PBKDF2 with SHA-256 for secure password storage.
        
        Args:
            password: The plain text password to hash
        """
        try:
            self.password_hash = generate_password_hash(password, method='pbkdf2:sha256')
            logger.debug(f"Password successfully set for user: {self.username}")
        except Exception as e:
            logger.error(f"Error setting password for user {self.username}: {str(e)}")
            raise

    def check_password(self, password: str) -> bool:
        """
        Verify a password against the stored hash.
        
        Args:
            password: The plain text password to verify
            
        Returns:
            bool: True if password matches, False otherwise
        """
        if self.is_oauth_user:
            logger.warning(f"Password check attempted for OAuth user: {self.username}")
            return False
            
        if not self.password_hash:
            logger.warning(f"Password check attempted for user without password: {self.username}")
            return False
            
        return check_password_hash(self.password_hash, password)

    def update_last_login(self) -> None:
        """
        Update the user's last login timestamp to current UTC time.
        Also ensures the change is committed to the database.
        """
        try:
            self.last_login = datetime.now(timezone.utc)
            db.session.commit()
            logger.debug(f"Updated last login for user: {self.username}")
        except Exception as e:
            logger.error(f"Error updating last login for user {self.username}: {str(e)}")
            db.session.rollback()
            raise

    @property
    def is_authenticated(self) -> bool:
        """
        Property indicating if the user is authenticated.
        Used by Flask-Login and similar extensions.
        
        Returns:
            bool: True if user is active and verified
        """
        return self.is_active and self.is_verified
    
    def generate_password_reset_token(self) -> str:
        """Generate a secure token for password reset."""
        try:
            serializer = URLSafeTimedSerializer(current_app.config['SECRET_KEY'])
            return serializer.dumps(self.email, salt='password-reset')
        except Exception as e:
            current_app.logger.error(f"Error generating reset token for user {self.email}: {str(e)}")
            raise

    @staticmethod
    def verify_reset_token(token: str, expiration: int = 3600) -> Optional['User']:
        """Verify the password reset token and return the associated user."""
        try:
            serializer = URLSafeTimedSerializer(current_app.config['SECRET_KEY'])
            email = serializer.loads(token, salt='password-reset', max_age=expiration)
            return User.query.filter_by(email=email).first()
        except Exception as e:
            current_app.logger.error(f"Error verifying reset token: {str(e)}")
            return None

    def __repr__(self) -> str:
        """
        String representation of the User model.
        Excludes sensitive information.
        """
        return f"<User username={self.username} email={self.email} oauth={self.is_oauth_user}>"
    
    