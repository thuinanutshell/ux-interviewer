from sqlalchemy.ext.declarative import declared_attr
from api.extensions import db
import re

class BaseModel(db.Model):
    __abstract__ = True

    @declared_attr
    def __tablename__(cls):
        """
        Generate a snake_case table name by converting the class name 
        and appending an 's' for pluralization.
        """
        snake_case_name = re.sub(r'(?<!^)(?=[A-Z])', '_', cls.__name__).lower()
        return f"{snake_case_name}s"