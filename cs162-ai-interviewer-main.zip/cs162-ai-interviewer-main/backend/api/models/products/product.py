from sqlalchemy import ForeignKey, String, Text, DateTime
from datetime import datetime, timezone
from api.models.base import BaseModel, db
from api.models.users import User
import uuid

class Product(BaseModel):
    product_id = db.Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    creator = db.Column(String(36), ForeignKey(f'{User.__tablename__}.user_id'), nullable=False)
    product_name = db.Column(String(255), nullable=False)
    product_url = db.Column(String(255), nullable=True)
    category = db.Column(String(255), nullable=True)
    description = db.Column(Text, nullable=True)
    created_at = db.Column(DateTime, nullable=False, default=lambda: datetime.now(timezone.utc))