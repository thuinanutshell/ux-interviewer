from .product import Product

__all__ = ['Product']