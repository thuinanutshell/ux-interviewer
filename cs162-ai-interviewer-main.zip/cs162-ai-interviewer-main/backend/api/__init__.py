from flask import Flask, Blueprint
from api.extensions import db, cors, jwt, migrate
from config import Config
from api.errors import handle_404, handle_500

# Blueprint imports
from .services.auth import auth_bp
from .services.analytics import analytics_bp
from .services.ai_integration import ai_integration_bp
from .services.interview import interview_bp
from .services.product import product_bp

# Add blueprints here to be registered
blueprints = [
    auth_bp,
    analytics_bp,
    ai_integration_bp,
    interview_bp,
    product_bp,
]


def create_app(config_class=Config):
    """
    Create and configure the Flask application.
    """
    app = Flask(__name__)
    app.config.from_object(config_class)

    # Initialize extensions
    cors.init_app(app)
    db.init_app(app)
    jwt.init_app(app)
    migrate.init_app(app, db)

    api = Blueprint('api', __name__, url_prefix='/api')

    # Register blueprints
    for blueprint in blueprints:
        api.register_blueprint(blueprint)

    app.register_blueprint(api)

    # Register global error handlers
    app.register_error_handler(404, handle_404)
    app.register_error_handler(500, handle_500)


    return app
