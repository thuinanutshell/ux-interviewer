# backend/api/services/interviews/routes.py
from flask import Blueprint, request, jsonify, session, render_template, redirect, url_for, flash

interview_bp = Blueprint('interview_bp', __name__)
from api.services.auth.routes import login_required
from .logic import InterviewService, InterviewError
import logging
from api.services.product.logic import ProductService, ProductError
from api.models import Interview, Participant, Product
from api.services.invitation.logic import InvitationService, InvitationError

logger = logging.getLogger(__name__)
product_service = ProductService()
invitation_service = InvitationService()
product_service = ProductService()
interview_service = InterviewService()

@interview_bp.route('/create', methods=['POST'])
@login_required
def create_interview():
    """Handle creation of a new interview."""
    try:
        interview_data = request.get_json()
        new_interview = interview_service.create_interview(
            session['user_id'],
            interview_data
        )
        return jsonify({
            'message': 'Interview created successfully',
            'interview': interview_service.interview_schema.dump(new_interview)
        }), 201
    except InterviewError as e:
        return jsonify({
            'error': str(e),
            'code': e.code
        }), 400
    except Exception as e:
        logger.error(f"Error creating interview: {str(e)}")
        return jsonify({
            'error': 'Internal server error',
            'code': 'INTERNAL_ERROR'
        }), 500

@interview_bp.route('/product/<product_id>', methods=['GET'])
@login_required
def get_product_interviews(product_id):
    """Retrieve all interviews associated with a specific product."""
    try:
        interviews = interview_service.get_product_interviews(product_id, session['user_id'])
        return jsonify({
            'interviews': interview_service.interviews_schema.dump(interviews)
        })
    except InterviewError as e:
        return jsonify({
            'error': str(e),
            'code': e.code
        }), 400
    except Exception as e:
        logger.error(f"Error retrieving product interviews: {str(e)}")
        return jsonify({
            'error': 'Internal server error',
            'code': 'INTERNAL_ERROR'
        }), 500

@interview_bp.route('/<interview_id>', methods=['GET', 'PUT', 'DELETE'])
@login_required
def manage_interview(interview_id):
    """Manage a specific interview (get, update, delete)."""
    try:
        if request.method == 'GET':
            interview = interview_service.get_interview(interview_id, session['user_id'])
            return jsonify(interview_service.interview_schema.dump(interview))
        elif request.method == 'PUT':
            updates = request.get_json()
            updated_interview = interview_service.update_interview(
                interview_id,
                session['user_id'],
                updates
            )
            return jsonify({
                'message': 'Interview updated successfully',
                'interview': interview_service.interview_schema.dump(updated_interview)
            })
        elif request.method == 'DELETE':
            interview_service.delete_interview(interview_id, session['user_id'])
            return jsonify({'message': 'Interview deleted successfully'})
    except InterviewError as e:
        return jsonify({
            'error': str(e),
            'code': e.code
        }), 404 if e.code == 'INTERVIEW_NOT_FOUND' else 400
    except Exception as e:
        logger.error(f"Error managing interview {interview_id}: {str(e)}")
        return jsonify({
            'error': 'Internal server error',
            'code': 'INTERNAL_ERROR'
        }), 500

@interview_bp.route('/portal/<product_id>')
@login_required
def portal(product_id):
    """Display the interview management portal for a product."""
    try:
        product = product_service.get_product(product_id, session['user_id'])
        interviews = interview_service.get_product_interviews(product_id, session['user_id'])
        
        # Get statistics for each interview
        for interview in interviews:
            interview.stats = interview_service.get_interview_stats(interview.interview_id)
            
        return render_template('interview/portal.html', 
                             product=product,
                             interviews=interviews)
    except Exception as e:
        flash(str(e), 'error')
        return redirect(url_for('product.portal'))

@interview_bp.route('/participate/<token>')
def participate(token):
    """Handle interview participation through invitation token."""
    try:
        invitation = invitation_service.verify_invitation(token)
        if not invitation:
            flash('This invitation link is invalid or has expired.', 'error')
            return redirect(url_for('home'))

        interview = Interview.query.get(invitation.interview_id)
        participant = Participant.query.get(invitation.participant_id)
        
        if not interview or not participant:
            flash('Interview session not found.', 'error')
            return redirect(url_for('home'))
            
        # Get the associated product
        product = Product.query.get(interview.product_id)
        if not product:
            flash('Interview product not found.', 'error')
            return redirect(url_for('home'))

        return render_template('interview/participate.html',
                             interview=interview,
                             participant=participant,
                             invitation=invitation,
                             product=product)
    except Exception as e:
        logger.error(f"Error accessing interview: {str(e)}")
        flash('Unable to access interview', 'error')
        return redirect(url_for('home'))

@interview_bp.route('/response', methods=['POST'])
def save_response():
    """Save a participant's response to a question."""
    try:
        response_data = request.get_json()
        success = interview_service.save_response(
            participant_id=response_data['participant_id'],
            question_id=response_data['question_id'],
            response_text=response_data['response_text']
        )
        if success:
            return jsonify({'message': 'Response saved successfully'})
        return jsonify({'error': 'Failed to save response'}), 500
    except Exception as e:
        logger.error(f"Error saving response: {str(e)}")
        return jsonify({'error': 'Failed to save response'}), 500

@interview_bp.route('/transcribe', methods=['POST'])
def transcribe_audio():
    """Handle audio transcription requests."""
    try:
        if 'audio' not in request.files:
            return jsonify({'error': 'No audio file provided'}), 400
        
        audio_file = request.files['audio']
        transcribed_text = interview_service.transcribe_audio(audio_file)
        
        return jsonify({
            'text': transcribed_text,
            'message': 'Audio transcribed successfully'
        })
    except Exception as e:
        logger.error(f"Error transcribing audio: {str(e)}")
        return jsonify({'error': 'Failed to transcribe audio'}), 500

@interview_bp.route('/<interview_id>/questions', methods=['GET', 'POST'])
def manage_interview_questions(interview_id):
    """Handle interview questions - get all or create new."""
    try:
        # First, verify that the interview exists
        interview = Interview.query.get(interview_id)
        if not interview:
            logger.error(f"Interview {interview_id} not found")
            return jsonify({
                'error': 'Interview not found',
                'code': 'INTERVIEW_NOT_FOUND'
            }), 404

        if request.method == 'GET':
            # Retrieve and return formatted questions
            questions = interview_service.get_interview_questions(interview_id)
            logger.info(f"Successfully retrieved {len(questions)} questions for interview {interview_id}")
            return jsonify(questions)

        elif request.method == 'POST':
            question_data = request.get_json()
            new_question = interview_service.add_question(
                interview_id=interview_id,
                question_data=question_data
            )
            return jsonify({
                'message': 'Question added successfully',
                'question': {
                    'question_id': new_question.question_id,
                    'question': new_question.question,
                    'interview_id': new_question.interview_id
                }
            }), 201
            
    except InterviewError as e:
        logger.error(f"Interview error: {str(e)}")
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        logger.error(f"Unexpected error in manage_interview_questions: {str(e)}")
        return jsonify({'error': 'An unexpected error occurred'}), 500

@interview_bp.route('/<interview_id>/edit-questions', methods=['GET'])
@login_required
def edit_questions(interview_id):
    """Display the question management interface."""
    try:
        # Retrieve the interview and verify ownership
        interview = interview_service.get_interview(interview_id, session['user_id'])
        if not interview:
            flash('Interview not found.', 'error')
            return redirect(url_for('interview_bp.portal', product_id=interview.product_id))
        
        # Get the questions for this interview
        questions = interview_service.get_interview_questions(interview_id)
        
        # Render the question management interface
        return render_template('interview/questions.html', 
                             interview=interview,
                             questions=questions)
                             
    except InterviewError as e:
        flash(str(e), 'error')
        return redirect(url_for('product.portal'))
    except Exception as e:
        logger.error(f"Error accessing question management: {str(e)}")
        flash('An unexpected error occurred.', 'error')
        return redirect(url_for('product.portal'))

@interview_bp.route('/<interview_id>/questions/<question_id>', methods=['DELETE'])
@login_required
def delete_question(interview_id, question_id):
    """Handle deletion of an interview question."""
    try:
        success = interview_service.delete_question(question_id, interview_id)
        if success:
            return jsonify({'message': 'Question deleted successfully'})
        return jsonify({'error': 'Question not found'}), 404
            
    except InterviewError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        logger.error(f"Error deleting question: {str(e)}")
        return jsonify({'error': 'Failed to delete question'}), 500

@interview_bp.route('/<interview_id>/responses')
@login_required
def view_responses(interview_id):
    """Display all responses for an interview."""
    try:
        interview = interview_service.get_interview(interview_id, session['user_id'])
        if not interview:
            flash('Interview not found.', 'error')
            return redirect(url_for('interview_bp.portal', product_id=interview.product_id))
            
        questions = interview_service.get_interview_questions(interview_id)
        responses = interview_service.get_interview_responses(interview_id)
        
        return render_template('interview/responses.html',
                             interview=interview,
                             questions=questions,
                             responses=responses)
                             
    except Exception as e:
        logger.error(f"Error accessing responses: {str(e)}")
        flash('An unexpected error occurred.', 'error')
        return redirect(url_for('interview_bp.portal', product_id=interview.product_id))