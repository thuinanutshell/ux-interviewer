# backend/api/services/interview/__init__.py
from flask import Blueprint

interview_bp = Blueprint('interview_bp', __name__)

from . import routes

__all__ = ['interview_bp']