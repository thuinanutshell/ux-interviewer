# backend/api/services/interview/schemas.py
from marshmallow import Schema, fields, validate

class InterviewSchema(Schema):
    """Schema for validating and serializing interviews"""
    interview_id = fields.Str(dump_only=True)
    product_id = fields.Str(required=True)  # Add this field
    title = fields.Str(
        required=True, 
        validate=validate.Length(min=1, max=255)
    )
    description = fields.Str(allow_none=True)
    questions = fields.Nested('QuestionSchema', many=True, dump_only=True)

class QuestionSchema(Schema):
    """Schema for validating and serializing interview questions"""
    question_id = fields.Str(dump_only=True)
    question = fields.Str(required=True, validate=validate.Length(min=1))
    interview_id = fields.Str(dump_only=True)