# backend/api/services/interviews/logic.py
from typing import Optional, List, Dict
from api.models.interviews import Interview, Question, Participant  # Remove schema imports from here
from api.models.responses import Response
from api.extensions import db
from .schemas import InterviewSchema, QuestionSchema  # Import schemas from local schemas.py
import logging
import uuid
import speech_recognition as sr
from pydub import AudioSegment
import tempfile
from werkzeug.datastructures import FileStorage
import os
from datetime import datetime, timezone, timedelta

logger = logging.getLogger(__name__)

class InterviewError(Exception):
    """Custom exception for interview-related errors"""
    def __init__(self, message: str, code: str = None):
        super().__init__(message)
        self.code = code

class InterviewService:
    """Service for managing interview operations"""
    
    def __init__(self):
        self.interview_schema = InterviewSchema()
        self.interviews_schema = InterviewSchema(many=True)
        self.question_schema = QuestionSchema()

    def create_interview(self, user_id: str, interview_data: Dict) -> Interview:
        """Creates a new interview for a product"""
        try:
            validated_data = self.interview_schema.load(interview_data)
            
            new_interview = Interview(
                interview_id=str(uuid.uuid4()),
                creator=user_id,
                product_id=validated_data['product_id'],
                title=validated_data['title'],
                description=validated_data.get('description')
            )
            
            db.session.add(new_interview)
            db.session.commit()
            logger.info(f"Interview created successfully: {new_interview.interview_id}")
            return new_interview
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error creating interview: {str(e)}")
            raise InterviewError("Failed to create interview", "INTERVIEW_CREATE_ERROR")
   
        
    def add_question(self, interview_id: str, question_data: Dict) -> Question:
        """
        Add a new question to an interview.
        
        Args:
            interview_id: The ID of the interview
            question_data: Dictionary containing question information
            
        Returns:
            The newly created Question object
        """
        try:
            validated_data = self.question_schema.load(question_data)
            
            new_question = Question(
                question_id=str(uuid.uuid4()),
                interview_id=interview_id,
                question=validated_data['question']
            )
            
            db.session.add(new_question)
            db.session.commit()
            
            logger.info(f"Question added to interview {interview_id}")
            return new_question
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error adding question to interview {interview_id}: {str(e)}")
            raise InterviewError("Failed to add question", "QUESTION_CREATE_ERROR")
    
    def update_question(self, question_id: str, question_data: Dict) -> Question:
        """
        Update an existing interview question.
        
        Args:
            question_id: The ID of the question to update
            question_data: Dictionary containing updated question information
            
        Returns:
            The updated Question object
        """
        try:
            question = Question.query.get(question_id)
            if not question:
                raise InterviewError("Question not found", "QUESTION_NOT_FOUND")
                
            validated_data = self.question_schema.load(question_data, partial=True)
            
            for key, value in validated_data.items():
                setattr(question, key, value)
                
            db.session.commit()
            logger.info(f"Question {question_id} updated successfully")
            
            return question
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error updating question {question_id}: {str(e)}")
            raise InterviewError("Failed to update question", "QUESTION_UPDATE_ERROR")

    def get_interview(self, interview_id: str, user_id: str) -> Optional[Interview]:
        """Retrieves a specific interview"""
        try:
            interview = Interview.query.filter_by(
                interview_id=interview_id,
                creator=user_id
            ).first()
            
            if not interview:
                raise InterviewError("Interview not found", "INTERVIEW_NOT_FOUND")
            return interview
            
        except Exception as e:
            logger.error(f"Error retrieving interview {interview_id}: {str(e)}")
            raise

    def get_product_interviews(self, product_id: str, user_id: str) -> List[Interview]:
        """Retrieves all interviews for a specific product"""
        try:
            return Interview.query.filter_by(
                product_id=product_id,
                creator=user_id
            ).all()
        except Exception as e:
            logger.error(f"Error retrieving product interviews: {str(e)}")
            raise InterviewError("Failed to retrieve interviews", "INTERVIEW_FETCH_ERROR")

    def update_interview(self, interview_id: str, user_id: str, updates: Dict) -> Interview:
        """Updates an existing interview"""
        try:
            interview = self.get_interview(interview_id, user_id)
            validated_updates = self.interview_schema.load(updates, partial=True)
            
            for field, value in validated_updates.items():
                setattr(interview, field, value)
                
            db.session.commit()
            logger.info(f"Interview updated successfully: {interview_id}")
            return interview
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error updating interview {interview_id}: {str(e)}")
            raise InterviewError("Failed to update interview", "INTERVIEW_UPDATE_ERROR")

    def delete_interview(self, interview_id: str, user_id: str) -> bool:
        """Deletes an interview and its associated questions"""
        try:
            interview = self.get_interview(interview_id, user_id)
            db.session.delete(interview)
            db.session.commit()
            logger.info(f"Interview deleted successfully: {interview_id}")
            return True
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error deleting interview {interview_id}: {str(e)}")
            raise InterviewError("Failed to delete interview", "INTERVIEW_DELETE_ERROR")
    
    def transcribe_audio(self, audio_file: FileStorage) -> str:
        """
        Transcribe audio from browser recording to text.
        """
        try:
            # Create a temporary directory for audio processing
            with tempfile.TemporaryDirectory() as temp_dir:
                # Save the original audio file
                webm_path = os.path.join(temp_dir, 'input.webm')
                audio_file.save(webm_path)

                # Convert to WAV format
                wav_path = os.path.join(temp_dir, 'output.wav')
                audio = AudioSegment.from_file(webm_path)
                audio.export(wav_path, format='wav', parameters=['-ar', '16000'])

                # Perform transcription
                recognizer = sr.Recognizer()
                with sr.AudioFile(wav_path) as source:
                    audio_data = recognizer.record(source)
                    text = recognizer.recognize_google(audio_data)
                    return text

        except sr.UnknownValueError as e:
            logger.error("Speech recognition failed to understand audio")
            raise InterviewError("Unable to recognize speech in recording", "RECOGNITION_ERROR")

        except sr.RequestError as e:
            logger.error(f"Speech recognition service error: {str(e)}")
            raise InterviewError("Speech recognition service unavailable", "SERVICE_ERROR")

        except Exception as e:
            logger.error(f"Audio transcription error: {str(e)}")
            raise InterviewError("Audio processing failed", "PROCESSING_ERROR")
    
    def save_response(self, participant_id: str, question_id: str, response_text: str) -> bool:
        """
        Save a participant's response to an interview question.
        
        Args:
            participant_id: The unique identifier of the participant
            question_id: The unique identifier of the question
            response_text: The participant's response text
            
        Returns:
            bool: True if the response was saved successfully
            
        Raises:
            InterviewError: If saving the response fails
        """
        try:
            # Check if a response already exists
            existing_response = Response.query.filter_by(
                participant_id=participant_id,
                question_id=question_id
            ).first()

            if existing_response:
                # Update existing response
                existing_response.response_text = response_text
                existing_response.completed_at = datetime.now(timezone.utc)
            else:
                # Create new response
                new_response = Response(
                    participant_id=participant_id,
                    question_id=question_id,
                    response_text=response_text,
                    completed_at=datetime.now(timezone.utc)
                )
                db.session.add(new_response)

            db.session.commit()
            logger.info(f"Response saved successfully for question {question_id}")
            return True

        except Exception as e:
            db.session.rollback()
            logger.error(f"Error saving response: {str(e)}")
            raise InterviewError("Failed to save response", "RESPONSE_SAVE_ERROR")
    
    def delete_question(self, question_id: str, interview_id: str) -> bool:
        """
        Delete a specific question and ensure it's properly removed from the database.
        """
        try:
            question = Question.query.filter_by(
                question_id=question_id,
                interview_id=interview_id
            ).first()
            
            if not question:
                logger.warning(f"Attempted to delete non-existent question: {question_id}")
                return False
                
            db.session.delete(question)
            db.session.commit()
            logger.info(f"Successfully deleted question {question_id}")
            return True
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error deleting question {question_id}: {str(e)}")
            raise InterviewError("Failed to delete question", "QUESTION_DELETE_ERROR")

    def get_interview_questions(self, interview_id: str) -> List[Question]:
        """Retrieve active questions for an interview with proper error handling."""
        try:
            # Verify interview exists
            interview = Interview.query.get(interview_id)
            if not interview:
                logger.error(f"Interview not found: {interview_id}")
                raise InterviewError("Interview not found", "INTERVIEW_NOT_FOUND")

            # Retrieve questions with proper ordering
            questions = Question.query.filter_by(
                interview_id=interview_id
            ).order_by(Question.created_at.asc()).all()
            
            # Format questions for response
            formatted_questions = []
            for q in questions:
                formatted_questions.append({
                    'question_id': q.question_id,
                    'question': q.question,
                    'interview_id': q.interview_id
                })
            
            # Log for debugging
            logger.info(f"Retrieved {len(questions)} questions for interview {interview_id}")
            
            return formatted_questions
            
        except InterviewError:
            raise
        except Exception as e:
            logger.error(f"Database error retrieving questions: {str(e)}")
            raise InterviewError(
                "Failed to retrieve interview questions", 
                "QUESTION_FETCH_ERROR"
            )
            
    def get_interview_stats(self, interview_id: str) -> Dict:
        """Get overall statistics for an interview."""
        try:
            # Get counts from database
            participant_count = Participant.query.join(Response).filter(
                Response.question_id == Question.question_id,
                Question.interview_id == interview_id
            ).distinct().count()
            
            question_count = Question.query.filter_by(
                interview_id=interview_id
            ).count()
            
            response_count = Response.query.join(Question).filter(
                Question.interview_id == interview_id
            ).count()
            
            return {
                'participant_count': participant_count,
                'question_count': question_count,
                'response_count': response_count
            }
        except Exception as e:
            logger.error(f"Error getting interview stats: {str(e)}")
            raise InterviewError("Failed to get interview statistics", "STATS_FETCH_ERROR")

    def get_interview_responses(self, interview_id: str) -> Dict:
        """Retrieve all responses for an interview grouped by question."""
        try:
            # Get all questions for this interview
            questions = Question.query.filter_by(interview_id=interview_id).all()
            
            # Initialize response dictionary
            responses = {}
            
            # For each question, get its responses
            for question in questions:
                question_responses = db.session.query(
                    Response, Participant
                ).join(
                    Participant, Response.participant_id == Participant.participant_id
                ).filter(
                    Response.question_id == question.question_id
                ).all()
                
                # Format responses for the question
                responses[question.question_id] = [{
                    'response_text': r.Response.response_text,
                    'completed_at': r.Response.completed_at,
                    'participant_email': r.Participant.email
                } for r in question_responses]
            
            return responses
            
        except Exception as e:
            logger.error(f"Error retrieving responses: {str(e)}")
            raise InterviewError("Failed to retrieve responses", "RESPONSE_FETCH_ERROR")