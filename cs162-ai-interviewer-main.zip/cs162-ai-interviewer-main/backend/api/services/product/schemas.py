# backend/api/services/product/schemas.py
from marshmallow import Schema, fields, validate, ValidationError

class ProductSchema(Schema):
    """Schema for validating and serializing product data"""
    product_id = fields.Str(dump_only=True)
    product_name = fields.Str(
        required=True, 
        validate=validate.Length(min=1, max=255),
        error_messages={"required": "Product name is required."}
    )
    product_url = fields.URL(
        missing=None, 
        allow_none=True,
        error_messages={"invalid": "Please provide a valid URL."}
    )
    category = fields.Str(
        validate=validate.Length(max=255), 
        allow_none=True
    )
    description = fields.Str(allow_none=True)
    created_at = fields.DateTime(dump_only=True)

    class Meta:
        ordered = True

class ProductUpdateSchema(ProductSchema):
    """Schema for validating product updates with optional fields"""
    product_name = fields.Str(
        validate=validate.Length(min=1, max=255),
        required=False
    )