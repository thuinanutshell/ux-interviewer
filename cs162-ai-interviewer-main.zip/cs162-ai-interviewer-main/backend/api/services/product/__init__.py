# backend/api/services/product/__init__.py
from flask import Blueprint

# Create the blueprint with the correct name
product_bp = Blueprint('product', __name__, url_prefix='/product')

# Import routes after blueprint creation to avoid circular imports
from . import routes

# Export the blueprint
__all__ = ['product_bp']