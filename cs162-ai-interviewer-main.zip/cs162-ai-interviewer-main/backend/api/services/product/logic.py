# backend/api/services/product/logic.py
from typing import Optional, List, Dict
from api.models.products import Product
from api.extensions import db
from datetime import datetime, timezone
from .schemas import ProductSchema, ProductUpdateSchema
import logging
from marshmallow import ValidationError

logger = logging.getLogger(__name__)

class ProductError(Exception):
    """Custom exception for handling product-related errors"""
    def __init__(self, message: str, code: str = None):
        super().__init__(message)
        self.code = code

class ProductService:
    """Service class for managing product operations"""
    def __init__(self):
        self.product_schema = ProductSchema()
        self.product_update_schema = ProductUpdateSchema()
        self.products_schema = ProductSchema(many=True)

    def create_product(self, user_id: str, product_data: Dict) -> Product:
        """Creates a new product for the specified user"""
        try:
            validated_data = self.product_schema.load(product_data)
            new_product = Product(creator=user_id, **validated_data)
            db.session.add(new_product)
            db.session.commit()
            logger.info(f"Product created successfully: {new_product.product_id}")
            return new_product
            
        except ValidationError as e:
            logger.error(f"Validation error: {str(e.messages)}")
            raise ProductError("Invalid product data", "VALIDATION_ERROR")
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error creating product: {str(e)}")
            raise ProductError("Failed to create product", "PRODUCT_CREATE_ERROR")

    def get_user_products(self, user_id: str) -> List[Product]:
        """Retrieves all products for a specific user"""
        try:
            return Product.query.filter_by(creator=user_id).order_by(
                Product.created_at.desc()
            ).all()
        except Exception as e:
            logger.error(f"Error retrieving user products: {str(e)}")
            raise ProductError("Failed to retrieve products", "PRODUCT_FETCH_ERROR")

    def get_product(self, product_id: str, user_id: str) -> Optional[Product]:
        """Retrieves a specific product for a user"""
        try:
            product = Product.query.filter_by(
                product_id=product_id, 
                creator=user_id
            ).first()
            
            if not product:
                raise ProductError("Product not found", "PRODUCT_NOT_FOUND")
            return product
        except ProductError:
            raise
        except Exception as e:
            logger.error(f"Error retrieving product {product_id}: {str(e)}")
            raise ProductError("Failed to retrieve product", "PRODUCT_FETCH_ERROR")

    def update_product(self, product_id: str, user_id: str, updates: Dict) -> Product:
        """Updates a specific product"""
        try:
            product = self.get_product(product_id, user_id)
            validated_updates = self.product_update_schema.load(updates, partial=True)
            
            for field, value in validated_updates.items():
                setattr(product, field, value)
                
            db.session.commit()
            logger.info(f"Product updated successfully: {product_id}")
            return product
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error updating product {product_id}: {str(e)}")
            raise ProductError("Failed to update product", "PRODUCT_UPDATE_ERROR")

    def delete_product(self, product_id: str, user_id: str) -> bool:
        """Deletes a specific product"""
        try:
            product = self.get_product(product_id, user_id)
            db.session.delete(product)
            db.session.commit()
            logger.info(f"Product deleted successfully: {product_id}")
            return True
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error deleting product {product_id}: {str(e)}")
            raise ProductError("Failed to delete product", "PRODUCT_DELETE_ERROR")