# backend/api/services/product/routes.py
from flask import Blueprint, request, jsonify, session, render_template, flash, url_for, redirect
from api.services.auth.routes import login_required
from .logic import ProductService, ProductError
import logging

logger = logging.getLogger(__name__)
product_bp = Blueprint('product', __name__, url_prefix='/product')
product_service = ProductService()

@product_bp.route('/', methods=['GET'])
@login_required
def get_user_products():
    """Retrieve all products for the authenticated user."""
    try:
        products = product_service.get_user_products(session['user_id'])
        return jsonify({
            'products': product_service.products_schema.dump(products)
        })
        
    except ProductError as e:
        return jsonify({
            'error': str(e),
            'code': e.code
        }), 400
    except Exception as e:
        logger.error(f"Error retrieving products: {str(e)}")
        return jsonify({
            'error': 'Internal server error',
            'code': 'INTERNAL_ERROR'
        }), 500

@product_bp.route('/<product_id>', methods=['GET'])
@login_required
def get_product(product_id):
    """Retrieve a specific product by ID."""
    try:
        product = product_service.get_product(product_id, session['user_id'])
        return jsonify(product_service.product_schema.dump(product))
        
    except ProductError as e:
        return jsonify({
            'error': str(e),
            'code': e.code
        }), 404 if e.code == 'PRODUCT_NOT_FOUND' else 400
    except Exception as e:
        logger.error(f"Error retrieving product {product_id}: {str(e)}")
        return jsonify({
            'error': 'Internal server error',
            'code': 'INTERNAL_ERROR'
        }), 500

@product_bp.route('/<product_id>', methods=['GET', 'PUT', 'POST', 'DELETE'])
@login_required
def manage_product(product_id):
    """Handle existing product management operations."""
    try:
        if request.method == 'GET':
            product = product_service.get_product(product_id, session['user_id'])
            return render_template('product/edit.html', product=product)
            
        elif request.method in ['PUT', 'POST']:
            updates = request.form.to_dict() if request.form else request.get_json()
            updated_product = product_service.update_product(
                product_id, 
                session['user_id'], 
                updates
            )
            
            flash('Product updated successfully', 'success')
            return redirect(url_for('product.portal'))
            
        elif request.method == 'DELETE':
            product_service.delete_product(product_id, session['user_id'])
            return jsonify({'message': 'Product deleted successfully'})
            
    except ProductError as e:
        if request.method == 'GET':
            flash(str(e), 'error')
            return redirect(url_for('product.portal'))
        return jsonify({
            'error': str(e),
            'code': e.code
        }), 404 if e.code == 'PRODUCT_NOT_FOUND' else 400
    except Exception as e:
        logger.error(f"Error managing product {product_id}: {str(e)}")
        if request.method == 'GET':
            flash('An unexpected error occurred', 'error')
            return redirect(url_for('product.portal'))
        return jsonify({
            'error': 'Internal server error',
            'code': 'INTERNAL_ERROR'
        }), 500
        
@product_bp.route('/portal')
@login_required
def portal():
    """Display the product management portal."""
    try:
        products = product_service.get_user_products(session['user_id'])
        return render_template('product/portal.html', products=products)
    except Exception as e:
        logger.error(f"Error displaying product portal: {str(e)}")
        flash('Error loading products', 'error')
        return redirect(url_for('home'))

# backend/api/services/product/routes.py

@product_bp.route('/create', methods=['GET', 'POST'])
@login_required
def create_product():
    """Handle product creation."""
    if request.method == 'GET':
        return render_template('product/create.html')

    try:
        product_data = request.form.to_dict()
        new_product = product_service.create_product(
            session['user_id'], 
            product_data
        )
        
        flash('Product created successfully', 'success')
        return redirect(url_for('product.portal'))
        
    except ProductError as e:
        flash(str(e), 'error')
        return redirect(url_for('product.create'))
    except Exception as e:
        logger.error(f"Error creating product: {str(e)}")
        flash('An unexpected error occurred', 'error')
        return redirect(url_for('product.create'))

@product_bp.route('/edit/<product_id>')
@login_required
def edit(product_id):
    """Display the edit product form."""
    try:
        product = product_service.get_product(product_id, session['user_id'])
        return render_template('product/edit.html', product=product)
    except ProductError:
        flash('Product not found', 'error')
        return redirect(url_for('product.portal'))