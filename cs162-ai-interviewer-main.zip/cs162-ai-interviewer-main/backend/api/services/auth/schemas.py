# backend/api/services/auth/schema.py
from marshmallow import Schema, fields, validate, ValidationError, post_load
from api.models import User  # Import the User model
from api.extensions import ma

class LoginSchema(Schema):
    """Schema for validating login requests"""
    identifier = fields.String(required=True, validate=validate.Length(min=3, max=150))
    password = fields.String(required=True, validate=validate.Length(min=8))

class RegistrationSchema(Schema):
    """Schema for validating registration requests"""
    username = fields.String(
        required=True,
        validate=[
            validate.Length(min=3, max=150),
            validate.Regexp(
                r'^[\w.-]+$',
                error='Username can only contain letters, numbers, dots, and dashes'
            )
        ]
    )
    email = fields.Email(required=True)
    password = fields.String(
        required=True,
        validate=[
            validate.Length(min=8),
            validate.Regexp(
                r'(?=.*\d)(?=.*[a-z])(?=.*[A-Z])',
                error='Password must contain at least one uppercase letter, one lowercase letter, and one number'
            )
        ]
    )

class UserSchema(ma.SQLAlchemySchema):
    """Schema for serializing user data"""
    class Meta:
        model = User

    username = fields.String()
    email = fields.String()
    created_at = fields.DateTime(format='%Y-%m-%d %H:%M:%S')
    last_login = fields.DateTime(format='%Y-%m-%d %H:%M:%S')
    is_oauth_user = fields.Boolean()

    @post_load
    def make_user(self, data, **kwargs):
        """Convert validated data into a User instance"""
        return User(**data)

# Create schema instances for both single objects and collections
user_schema = UserSchema()
users_schema = UserSchema(many=True)