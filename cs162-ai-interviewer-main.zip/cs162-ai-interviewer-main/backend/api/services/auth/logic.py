from flask import current_app, url_for
from api.models.users import User
from api.extensions import db, oauth
from .schemas import LoginSchema, RegistrationSchema, UserSchema
from marshmallow import ValidationError
from datetime import datetime, timezone
import logging
from typing import Dict, Optional, Tuple, Any
import os

# Set up logging
logger = logging.getLogger(__name__)

class AuthenticationError(Exception):
    """Custom exception for authentication-related errors with context"""
    def __init__(self, message: str, code: str = None):
        super().__init__(message)
        self.code = code

class AuthenticationService:
    """
    Comprehensive service for handling all authentication-related operations.
    Provides a clean interface between the web routes and the User model.
    """
    
    def __init__(self):
        # Initialize schema validators
        self.login_schema = LoginSchema()
        self.registration_schema = RegistrationSchema()
        self.user_schema = UserSchema()
        
        # Initialize Google OAuth configuration
        self._setup_google_oauth()

    def _setup_google_oauth(self) -> None:
        """
        Configure Google OAuth settings. This is called during service initialization
        to set up the Google OAuth client with proper credentials and scopes.
        """
        try:
            self.google = oauth.register(
                name='google',
                client_id=os.getenv('GOOGLE_CLIENT_ID'),
                client_secret=os.getenv('GOOGLE_CLIENT_SECRET'),
                server_metadata_url='https://accounts.google.com/.well-known/openid-configuration',
                client_kwargs={
                    'scope': 'openid email profile',
                    'prompt': 'select_account'  # Always show account selector
                }
            )
            logger.info("Google OAuth client configured successfully")
        except Exception as e:
            logger.error(f"Failed to configure Google OAuth: {str(e)}")
            raise AuthenticationError("OAuth configuration failed", "OAUTH_CONFIG_ERROR")

    def initiate_google_oauth(self, redirect_uri: str) -> Any:
        """
        Start the Google OAuth authentication flow.
        
        Args:
            redirect_uri: The URL to return to after Google authentication
            
        Returns:
            Redirect response to Google's authorization page
            
        Raises:
            AuthenticationError: If OAuth initialization fails
        """
        try:
            return self.google.authorize_redirect(redirect_uri)
        except Exception as e:
            logger.error(f"Error initiating Google OAuth: {str(e)}")
            raise AuthenticationError("Failed to start Google authentication", "OAUTH_INIT_ERROR")

    def process_oauth_callback(self) -> User:
        """
        Handle the OAuth callback from Google and create/update user accordingly.
        When Google redirects back to our application, this method:
        1. Exchanges the authorization code for an access token
        2. Uses the token to fetch the user's profile from Google
        3. Creates or updates the user in our database
        """
        try:
            # First, exchange the authorization code for an access token
            token = self.google.authorize_access_token()
            if not token:
                logger.error("No token received from Google")
                raise AuthenticationError("No token received from Google", "OAUTH_TOKEN_ERROR")
            
            # Now use the token to get user information - note the complete URL
            userinfo_response = self.google.get('https://www.googleapis.com/oauth2/v3/userinfo')
            if not userinfo_response:
                logger.error("Failed to get user info from Google")
                raise AuthenticationError("Failed to get user info", "OAUTH_USERINFO_ERROR")
                
            google_user = userinfo_response.json()
            
            # Extract essential user information
            email = google_user.get('email')
            if not email:
                logger.error("No email provided in Google response")
                raise AuthenticationError("No email provided by Google", "OAUTH_EMAIL_MISSING")
                
            # Get or create the user in our database
            user = self.process_oauth_login({
                'email': email,
                'username': google_user.get('name', email.split('@')[0]),  # Use email prefix as fallback username
                'is_verified': google_user.get('email_verified', False)
            })
            
            logger.info(f"Successfully processed OAuth login for: {email}")
            return user
            
        except Exception as e:
            logger.error(f"Error processing Google callback: {str(e)}")
            if not isinstance(e, AuthenticationError):
                raise AuthenticationError("Google authentication failed", "OAUTH_CALLBACK_ERROR")
            raise

class AuthenticationService:
    def __init__(self):
        self.login_schema = LoginSchema()
        self.registration_schema = RegistrationSchema()
        self.user_schema = UserSchema()
        self.google = None
        self._setup_google_oauth()

    def _setup_google_oauth(self) -> None:
        try:
            self.google = oauth.register(
                name='google',
                client_id=os.getenv('GOOGLE_CLIENT_ID'),
                client_secret=os.getenv('GOOGLE_CLIENT_SECRET'),
                server_metadata_url='https://accounts.google.com/.well-known/openid-configuration',
                client_kwargs={
                    'scope': 'openid email profile',
                    'prompt': 'select_account'
                }
            )
            logger.info("Google OAuth client configured successfully")
        except Exception as e:
            logger.error(f"Failed to configure Google OAuth: {str(e)}")
            raise AuthenticationError("OAuth configuration failed", "OAUTH_CONFIG_ERROR")

    def initiate_google_oauth(self, redirect_uri: str) -> Any:
        try:
            if not self.google:
                self._setup_google_oauth()
            return self.google.authorize_redirect(redirect_uri)
        except Exception as e:
            logger.error(f"Error initiating Google OAuth: {str(e)}")
            raise AuthenticationError("Failed to start Google authentication", "OAUTH_INIT_ERROR")

    def authenticate_user(self, identifier: str, password: str) -> Tuple[User, bool]:
        try:
            if '@' in identifier:
                user = User.query.filter_by(email=identifier).first()
            else:
                user = User.query.filter_by(username=identifier).first()
            
            if not user:
                logger.warning(f"Authentication attempt for non-existent user: {identifier}")
                raise AuthenticationError("Invalid credentials", "INVALID_CREDENTIALS")
                
            if not user.is_active:
                logger.warning(f"Authentication attempt for inactive user: {identifier}")
                raise AuthenticationError("Account is inactive", "INACTIVE_ACCOUNT")
                
            if not user.is_verified and not user.is_oauth_user:
                logger.warning(f"Authentication attempt for unverified user: {identifier}")
                raise AuthenticationError("Please verify your email before logging in", "EMAIL_NOT_VERIFIED")
                
            if not user.check_password(password):
                logger.warning(f"Failed password check for user: {identifier}")
                raise AuthenticationError("Invalid credentials", "INVALID_CREDENTIALS")
                
            user.update_last_login()
            logger.info(f"Successful authentication for user: {identifier}")
            
            return user, True
            
        except Exception as e:
            if not isinstance(e, AuthenticationError):
                logger.error(f"Unexpected error during authentication: {str(e)}")
                raise AuthenticationError("Authentication failed", "SYSTEM_ERROR")
            raise

    def register_new_user(self, user_data: Dict) -> User:
        try:
            validated_data = self.registration_schema.load(user_data)
            
            if User.query.filter_by(username=validated_data['username']).first():
                raise AuthenticationError("Username already exists", "USERNAME_TAKEN")
                
            if User.query.filter_by(email=validated_data['email']).first():
                raise AuthenticationError("Email already registered", "EMAIL_TAKEN")
                
            new_user = User(
                username=validated_data['username'],
                email=validated_data['email'],
                is_verified=False
            )
            new_user.set_password(validated_data['password'])
            
            verification_token = new_user.generate_verification_token()
            
            db.session.add(new_user)
            db.session.commit()
            
            self._send_verification_email(new_user.email, verification_token)
            
            logger.info(f"Successfully registered new user and sent verification email: {new_user.username}")
            return new_user
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error during user registration: {str(e)}")
            if not isinstance(e, AuthenticationError):
                raise AuthenticationError("Registration failed", "SYSTEM_ERROR")
            raise

    def _send_verification_email(self, email: str, token: str) -> None:
        try:
            email_service = current_app.email_service
            email_service.send_verification_email(email, token)
            logger.info(f"Verification email sent successfully to {email}")
        except Exception as e:
            logger.error(f"Failed to send verification email to {email}: {str(e)}")
            raise AuthenticationError("Failed to send verification email", "EMAIL_SEND_ERROR")

    def process_oauth_login(self, oauth_data: Dict) -> User:
        """
        Enhanced version of your existing process_oauth_login method with improved
        error handling and logging.
        
        Args:
            oauth_data: Dictionary containing OAuth provider's user data
            
        Returns:
            User: The user object (either existing or newly created)
            
        Raises:
            AuthenticationError: If OAuth processing fails
        """
        try:
            email = oauth_data.get('email')
            if not email:
                raise AuthenticationError("No email provided by OAuth provider", "OAUTH_EMAIL_MISSING")
                
            user = User.query.filter_by(email=email).first()
            
            if user:
                logger.info(f"Existing user found for OAuth login: {email}")
                # Update existing user's OAuth status if needed
                if not user.is_oauth_user:
                    user.is_oauth_user = True
                    logger.info(f"Updated user OAuth status: {email}")
                    db.session.commit()
            else:
                logger.info(f"Creating new user for OAuth login: {email}")
                # Create new OAuth user
                username = self._generate_unique_username(email)
                user = User(
                    username=username,
                    email=email,
                    is_oauth_user=True,
                    is_verified=oauth_data.get('is_verified', True)
                )
                db.session.add(user)
                db.session.commit()
                logger.info(f"Created new OAuth user: {username}")
                
            user.update_last_login()
            return user
        except Exception as e:
            logger.error(f"Error processing OAuth login: {str(e)}")
            raise AuthenticationError("OAuth login failed", "OAUTH_LOGIN_ERROR")

    def process_oauth_callback(self) -> User:
        """Process the OAuth callback from Google"""
        try:
            token = self.google.authorize_access_token()
            if not token:
                logger.error("No token received from Google")
                raise AuthenticationError("No token received from Google", "OAUTH_TOKEN_ERROR")
            
            # Add error logging for token debugging
            logger.info("Received OAuth token structure")
            
            userinfo = self.google.userinfo()  # Changed from direct API call
            if not userinfo:
                logger.error("Failed to get user info from Google")
                raise AuthenticationError("Failed to get user info", "OAUTH_USERINFO_ERROR")
            
            email = userinfo.get('email')
            if not email:
                logger.error("No email provided in Google response")
                raise AuthenticationError("No email provided by Google", "OAUTH_EMAIL_MISSING")
                
            # Process OAuth login with verified information
            user = self.process_oauth_login({
                'email': email,
                'username': userinfo.get('name', email.split('@')[0]),
                'is_verified': userinfo.get('email_verified', False)
            })
            
            logger.info(f"Successfully processed OAuth login for: {email}")
            return user
                
        except Exception as e:
            logger.error(f"OAuth callback error: {str(e)}", exc_info=True)
            raise AuthenticationError("OAuth authentication failed", "OAUTH_CALLBACK_ERROR")

    def _generate_unique_username(self, email: str) -> str:
        """Generate a unique username from email address."""
        base_username = email.split('@')[0]
        username = base_username
        counter = 1
        
        while User.query.filter_by(username=username).first():
            username = f"{base_username}{counter}"
            counter += 1
        
        return username
    
    def process_oauth_signup(self) -> User:
        """Process Google OAuth signup and create a new user account."""
        try:
            token = self.google.authorize_access_token()
            if not token:
                logger.error("No token received from Google during signup")
                raise AuthenticationError("No token received from Google", "OAUTH_TOKEN_ERROR")
            
            userinfo_response = self.google.get('https://www.googleapis.com/oauth2/v3/userinfo')
            if not userinfo_response:
                logger.error("Failed to get user info from Google during signup")
                raise AuthenticationError("Failed to get user info", "OAUTH_USERINFO_ERROR")
                
            google_user = userinfo_response.json()
            
            email = google_user.get('email')
            if not email:
                logger.error("No email provided in Google response during signup")
                raise AuthenticationError("No email provided by Google", "OAUTH_EMAIL_MISSING")
                
            existing_user = User.query.filter_by(email=email).first()
            if existing_user:
                logger.info(f"User already exists with email: {email}")
                raise AuthenticationError("An account already exists with this email. Please sign in instead.", "EMAIL_EXISTS")
                
            username = self._generate_unique_username(email)
            new_user = User(
                username=username,
                email=email,
                is_oauth_user=True,
                is_verified=google_user.get('email_verified', True)
            )
            
            db.session.add(new_user)
            db.session.commit()
            logger.info(f"Created new user account via Google OAuth: {username}")
            
            new_user.update_last_login()
            return new_user
            
        except Exception as e:
            logger.error(f"Error processing OAuth signup: {str(e)}")
            if not isinstance(e, AuthenticationError):
                raise AuthenticationError("OAuth signup failed", "OAUTH_SIGNUP_ERROR")
            raise
