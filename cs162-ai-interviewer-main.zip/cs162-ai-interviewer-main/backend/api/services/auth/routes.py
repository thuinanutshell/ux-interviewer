# backend/api/services/auth/routes.py

from flask import (
    Blueprint, 
    request, 
    jsonify, 
    session, 
    redirect, 
    url_for, 
    current_app,
    render_template,
    flash
)
from api.extensions import db
from .logic import AuthenticationService, AuthenticationError
from api.models.users import User
from functools import wraps
import logging
from datetime import datetime, timezone

# Initialize logger for authentication routes
logger = logging.getLogger(__name__)

# Create Blueprint for authentication routes
auth_bp = Blueprint('auth', __name__, url_prefix='/auth', template_folder='templates')

# Initialize authentication service
auth_service = AuthenticationService()

def login_required(f):
    """
    Decorator to protect routes that require authentication.
    Handles both API and template-based requests appropriately.
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            # Check if request is expecting JSON
            if request.headers.get('Accept') == 'application/json':
                return jsonify({'error': 'Authentication required'}), 401
            flash('Please log in to access this page.', 'error')
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated_function

def handle_api_response(success_data, error_message=None, status_code=200):
    """
    Helper function to handle both API and template responses.
    Determines response type based on request headers.
    """
    if request.headers.get('Accept') == 'application/json':
        if error_message:
            return jsonify({'error': error_message}), status_code
        return jsonify(success_data), status_code
    
    if error_message:
        flash(error_message, 'error')
        return redirect(url_for('auth.login'))
    return success_data

@auth_bp.route('/')
def home():
    """Home route for authentication - shows login page or redirects to profile"""
    if 'user_id' in session:
        return redirect(url_for('auth.profile'))
    return render_template('auth/login.html')

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    """
    Handle user registration with email and password.
    Supports both form-based and API requests.
    """
    if request.method == 'GET':
        return render_template('auth/register.html')

    try:
        registration_data = request.get_json() if request.is_json else request.form.to_dict()
        user = auth_service.register_new_user(registration_data)
        
        session['user_id'] = user.user_id
        session.permanent = True
        
        success_response = {
            'message': 'Registration successful',
            'user': {
                'username': user.username,
                'email': user.email
            }
        }
        
        if request.headers.get('Accept') == 'application/json':
            return jsonify(success_response), 201
            
        flash('Registration successful! Welcome aboard!', 'success')
        return redirect(url_for('product.portal'))
        
    except AuthenticationError as e:
        logger.warning(f"Registration failed: {str(e)}")
        return handle_api_response(None, str(e), 400)
    except Exception as e:
        logger.error(f"Unexpected error during registration: {str(e)}")
        return handle_api_response(None, 'An unexpected error occurred', 500)

# In auth/routes.py, modify the login route
@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    """Handle login with username/email and password."""
    if request.method == 'GET':
        return render_template('auth/login.html')

    try:
        login_data = request.get_json() if request.is_json else request.form.to_dict()
        user, success = auth_service.authenticate_user(
            login_data.get('identifier'),
            login_data.get('password')
        )
        
        if success:
            session['user_id'] = user.user_id
            session.permanent = True
            
            # Modify this section to redirect to products page
            if request.headers.get('Accept') == 'application/json':
                return jsonify({'message': 'Login successful'})
                
            flash('Welcome back!', 'success')
            return redirect(url_for('product.portal'))  # New route we'll create
    except AuthenticationError as e:
        logger.warning(f"Login failed: {str(e)}")
        return handle_api_response(None, str(e), 401)
    except Exception as e:
        logger.error(f"Unexpected error during login: {str(e)}")
        return handle_api_response(None, 'An unexpected error occurred', 500)

@auth_bp.route('/logout')
def logout():
    """Handle user logout by clearing their session."""
    try:
        session.clear()
        if request.headers.get('Accept') == 'application/json':
            return jsonify({'message': 'Logout successful'})
            
        flash('You have been successfully logged out.', 'success')
        return redirect(url_for('auth.login'))
        
    except Exception as e:
        logger.error(f"Error during logout: {str(e)}")
        return handle_api_response(None, 'An error occurred during logout', 500)

@auth_bp.route('/profile')
@login_required
def profile():
    """Display user profile page or return profile data for API requests."""
    try:
        user = User.query.get(session['user_id'])
        if not user:
            session.clear()
            return handle_api_response(None, 'User not found', 404)
            
        if request.headers.get('Accept') == 'application/json':
            return jsonify({
                'username': user.username,
                'email': user.email,
                'created_at': user.created_at.isoformat(),
                'last_login': user.last_login.isoformat() if user.last_login else None,
                'is_verified': user.is_verified
            })
            
        return render_template('auth/profile.html', user=user)
        
    except Exception as e:
        logger.error(f"Error retrieving user profile: {str(e)}")
        return handle_api_response(None, 'An error occurred while retrieving profile', 500)

@auth_bp.route('/login/google')
def google_login():
    """Initialize Google OAuth login process"""
    try:
        redirect_uri = url_for('auth.google_callback', _external=True)
        return auth_service.initiate_google_oauth(redirect_uri)
    except Exception as e:
        logger.error(f"Error initiating Google OAuth: {str(e)}")
        flash('Failed to initialize Google login. Please try again.', 'error')
        return redirect(url_for('auth.login'))

@auth_bp.route('/login/google/callback')
def google_callback():
    """Handle Google OAuth callback"""
    try:
        user = auth_service.process_oauth_callback()
        session['user_id'] = user.user_id
        session.permanent = True
        
        flash('Successfully signed in with Google!', 'success')
        return redirect(url_for('product.portal'))
    except AuthenticationError as e:
        logger.warning(f"Google OAuth callback failed: {str(e)}")
        flash('Failed to sign in with Google. Please try again.', 'error')
        return redirect(url_for('auth.login'))

@auth_bp.route('/session/verify')
def verify_session():
    """Verify if the current session is valid and return basic user info."""
    try:
        if 'user_id' not in session:
            return handle_api_response(None, 'Not authenticated', 401)
            
        user = User.query.get(session['user_id'])
        if not user:
            session.clear()
            return handle_api_response(None, 'Not authenticated', 401)
            
        return jsonify({
            'authenticated': True,
            'user': {
                'username': user.username,
                'email': user.email,
                'is_verified': user.is_verified
            }
        })
        
    except Exception as e:
        logger.error(f"Error verifying session: {str(e)}")
        return handle_api_response(None, 'An error occurred while verifying session', 500)

@auth_bp.route('/password/change', methods=['POST'])
@login_required
def change_password():
    """Allow authenticated users to change their password."""
    try:
        data = request.get_json() if request.is_json else request.form.to_dict()
        user = User.query.get(session['user_id'])
        
        if not user.check_password(data.get('current_password')):
            return handle_api_response(None, 'Current password is incorrect', 401)
            
        user.set_password(data.get('new_password'))
        db.session.commit()
        
        if request.headers.get('Accept') == 'application/json':
            return jsonify({'message': 'Password successfully updated'})
            
        flash('Your password has been successfully updated.', 'success')
        return redirect(url_for('auth.profile'))
        
    except Exception as e:
        logger.error(f"Error changing password: {str(e)}")
        return handle_api_response(None, 'An error occurred while changing password', 500)

# backend/api/services/auth/routes.py

@auth_bp.route('/signup/google')
def google_signup():
    """Initialize Google OAuth signup process"""
    try:
        redirect_uri = url_for('auth.google_signup_callback', _external=True)
        return auth_service.initiate_google_oauth(redirect_uri)
    except Exception as e:
        logger.error(f"Error initiating Google signup: {str(e)}")
        flash('Failed to initialize Google signup. Please try again.', 'error')
        return redirect(url_for('auth.register'))

@auth_bp.route('/signup/google/callback')
def google_signup_callback():
    """Handle Google OAuth signup callback"""
    try:
        user = auth_service.process_oauth_signup()
        session['user_id'] = user.user_id
        session.permanent = True
        
        flash('Account successfully created with Google!', 'success')
        return redirect(url_for('auth.profile'))
    except AuthenticationError as e:
        logger.warning(f"Google OAuth signup failed: {str(e)}")
        flash('Failed to create account with Google. Please try again.', 'error')
        return redirect(url_for('auth.register'))

# backend/api/services/auth/routes.py

@auth_bp.route('/verify-email/<token>')
def verify_email(token):
    try:
        user = User.verify_email_token(token)
        if not user:
            flash('The verification link is invalid or has expired.', 'error')
            return redirect(url_for('auth.login'))
        
        if user.is_verified:
            flash('Your email has already been verified. Please login.', 'info')
            return redirect(url_for('auth.login'))
        
        user.is_verified = True
        user.email_verified_at = datetime.now(timezone.utc)
        db.session.commit()
        
        flash('Your email has been verified successfully. You can now login.', 'success')
        return redirect(url_for('auth.login'))
        
    except Exception as e:
        logger.error(f"Error during email verification: {str(e)}")
        flash('An error occurred during verification. Please try again.', 'error')
        return redirect(url_for('auth.login'))


@auth_bp.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    """Handle forgotten password requests."""
    if request.method == 'GET':
        return render_template('auth/forgot_password.html')

    try:
        email = request.form.get('email')
        user = User.query.filter_by(email=email).first()
        
        if user and not user.is_oauth_user:
            token = user.generate_password_reset_token()
            current_app.email_service.send_password_reset_email(email, token)
            
        # Always show success to prevent email enumeration
        flash('If an account exists with that email, you will receive password reset instructions.', 'success')
        return redirect(url_for('auth.login'))
        
    except Exception as e:
        logger.error(f"Error in forgot password process: {str(e)}")
        flash('An error occurred. Please try again later.', 'error')
        return redirect(url_for('auth.forgot_password'))

@auth_bp.route('/reset-password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    """Handle password reset."""
    if request.method == 'GET':
        return render_template('auth/reset_password.html')

    try:
        user = User.verify_reset_token(token)
        if not user:
            flash('Invalid or expired reset link. Please try again.', 'error')
            return redirect(url_for('auth.forgot_password'))
            
        new_password = request.form.get('password')
        user.set_password(new_password)
        db.session.commit()
        
        flash('Your password has been successfully reset. Please log in.', 'success')
        return redirect(url_for('auth.login'))
        
    except Exception as e:
        logger.error(f"Error in password reset: {str(e)}")
        flash('An error occurred. Please try again.', 'error')
        return redirect(url_for('auth.forgot_password'))