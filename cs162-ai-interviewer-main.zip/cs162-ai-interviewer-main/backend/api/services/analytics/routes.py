# backend/api/services/analytics/routes.py
from flask import Blueprint, request, jsonify
from api.services.auth.routes import login_required
from .logic import AnalyticsService, AnalyticsError
from api.services.interview.logic import InterviewService
import logging

logger = logging.getLogger(__name__)
analytics_service = AnalyticsService()
interview_service = InterviewService()
analytics_service = AnalyticsService()
analytics_bp = Blueprint('analytics', __name__)

# backend/api/services/analytics/routes.py

@analytics_bp.route('/analyze/<interview_id>', methods=['POST'])
@login_required
def analyze_responses(interview_id):
    """Analyze interview responses using AI."""
    try:
        # Get questions and responses for the interview
        questions = interview_service.get_interview_questions(interview_id)
        responses = interview_service.get_interview_responses(interview_id)
        
        # Perform analysis
        analysis_results = analytics_service.analyze_interview_responses(
            interview_id,
            responses,
            questions
        )
        
        return jsonify(analysis_results)
        
    except AnalyticsError as e:
        return jsonify({
            'error': str(e),
            'code': e.code
        }), 400
    except Exception as e:
        logger.error(f"Error in response analysis: {str(e)}")
        return jsonify({
            'error': 'Failed to analyze responses',
            'code': 'ANALYSIS_ERROR'
        }), 500