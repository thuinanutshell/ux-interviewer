from marshmallow import Schema, fields

class AnalysisResultSchema(Schema):
    """Schema for interview response analysis results"""
    interview_id = fields.Str(dump_only=True)
    key_themes = fields.List(fields.Str(), dump_only=True)
    sentiment = fields.Dict(keys=fields.Str(), values=fields.Float(), dump_only=True)
    summary = fields.Str(dump_only=True)