import time
from typing import Dict, List
import logging
import google.generativeai as genai
from flask import current_app
from collections import Counter
from tenacity import retry, stop_after_attempt, wait_exponential
import json

logger = logging.getLogger(__name__)

class AnalyticsError(Exception):
    def __init__(self, message: str, code: str = None):
        super().__init__(message)
        self.code = code

class AnalyticsService:
    _instance = None
    _initialized = False

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if not self._initialized:
            self.max_retries = 3
            self.base_delay = 1
            self._initialized = True
            self.model = None

    def initialize_gemini(self):
        if self.model is None and current_app:
            api_key = current_app.config.get('GEMINI_API_KEY')
            if not api_key:
                raise AnalyticsError("Gemini API key not configured", code="CONFIG_ERROR")
            genai.configure(api_key=api_key)
            self.model = genai.GenerativeModel('gemini-pro')

    def _get_themes(self, content: str) -> List[str]:
        """Extract key themes from the content"""
        prompt = """Identify 3-5 key themes from these interview responses. 
        Return ONLY a comma-separated list of themes, with no additional text or explanation.
        Example format: theme1, theme2, theme3"""
        
        response = self.model.generate_content(prompt + "\n\n" + content)
        themes = [theme.strip() for theme in response.text.split(',')]
        return themes[:5]  # Ensure we don't exceed 5 themes

    def _get_sentiment(self, content: str) -> Dict:
        """Analyze sentiment of the content"""
        prompt = """Analyze the sentiment of these interview responses.
        Return ONLY two lines:
        1. A sentiment score between 0 and 1
        2. A brief explanation of the sentiment
        Example:
        0.7
        Generally positive with some concerns about specific aspects"""
        
        response = self.model.generate_content(prompt + "\n\n" + content)
        lines = response.text.strip().split('\n')
        
        try:
            score = float(lines[0].strip())
            explanation = lines[1].strip() if len(lines) > 1 else "Sentiment analysis completed"
            return {
                "overall": {
                    "score": max(0, min(1, score)),  # Ensure score is between 0 and 1
                    "explanation": explanation
                }
            }
        except (ValueError, IndexError):
            return {
                "overall": {
                    "score": 0.5,
                    "explanation": "Sentiment analysis completed"
                }
            }

    def _get_summary(self, content: str) -> str:
        """Generate a summary of the content"""
        prompt = """Provide a concise summary of these interview responses in a single paragraph.
        Return ONLY the summary text, with no additional explanation or formatting."""
        
        response = self.model.generate_content(prompt + "\n\n" + content)
        return response.text.strip()

    def analyze_interview_responses(self, interview_id: str, responses: Dict, questions: List[Dict]) -> Dict:
        try:
            # Format the data
            formatted_data = []
            for question_id, question_responses in responses.items():
                question_text = next((q['question'] for q in questions if q['question_id'] == question_id), "Unknown Question")
                question_data = {
                    "question": question_text,
                    "responses": question_responses
                }
                formatted_data.append(question_data)

            content = str(formatted_data)

            try:
                self.initialize_gemini()
                
                # Analyze content in steps
                themes = self._get_themes(content)
                sentiment = self._get_sentiment(content)
                summary = self._get_summary(content)
                
                # Assemble the final response
                analysis_result = {
                    "key_themes": themes,
                    "sentiment": sentiment,
                    "summary": summary
                }
                
                return analysis_result

            except Exception as api_error:
                logger.warning(f"Gemini analysis failed, using fallback: {str(api_error)}")
                return self._fallback_analysis(formatted_data)

        except Exception as e:
            logger.error(f"Analysis error: {str(e)}")
            raise AnalyticsError("Failed to analyze responses", code="ANALYSIS_ERROR")

    def _fallback_analysis(self, formatted_data: List[Dict]) -> Dict:
        """Perform basic analysis when API is unavailable"""
        all_text = " ".join([str(item) for item in formatted_data])
        words = all_text.lower().split()
        word_freq = Counter(words)
        
        positive_words = {'good', 'great', 'excellent', 'helpful', 'positive'}
        negative_words = {'bad', 'poor', 'difficult', 'negative', 'unhelpful'}
        
        pos_count = sum(1 for word in words if word in positive_words)
        neg_count = sum(1 for word in words if word in negative_words)
        sentiment_score = (pos_count - neg_count) / (pos_count + neg_count + 1)
        
        return {
            "key_themes": [word for word, _ in word_freq.most_common(5)],
            "sentiment": {
                "overall": {
                    "score": sentiment_score,
                    "explanation": "Basic sentiment analysis based on keyword frequency"
                }
            },
            "summary": "Fallback analysis performed due to API limitations"
        }