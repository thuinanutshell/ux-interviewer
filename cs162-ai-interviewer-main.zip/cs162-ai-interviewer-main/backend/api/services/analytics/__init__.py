from .routes import analytics_bp

__all__ = ['analytics_bp']