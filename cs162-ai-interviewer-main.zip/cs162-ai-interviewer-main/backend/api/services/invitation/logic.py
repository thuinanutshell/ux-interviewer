# backend/api/services/invitations/logic.py
from typing import Optional, List, Dict
from api.models.invitations import Invitation
from api.models.interviews import Participant
from api.models.interviews import Interview
from api.extensions import db
from api.services.invitation.schemas import InvitationSchema, ParticipantSchema
from datetime import datetime, timedelta, timezone
from itsdangerous import URLSafeTimedSerializer
from flask import current_app
import logging
import uuid
from sqlalchemy.exc import IntegrityError
from datetime import datetime, timezone

logger = logging.getLogger(__name__)

class InvitationError(Exception):
    """Custom exception for invitation-related errors"""
    def __init__(self, message: str, code: str = None):
        super().__init__(message)
        self.code = code

class InvitationService:
    """Service for managing interview invitations"""
    
    def __init__(self):
        self.invitation_schema = InvitationSchema()
        self.invitations_schema = InvitationSchema(many=True)
        self.participant_schema = ParticipantSchema()

    def generate_invitation_token(self) -> str:
        """Generate a secure token for interview invitation"""
        try:
            serializer = URLSafeTimedSerializer(current_app.config['SECRET_KEY'])
            return serializer.dumps(str(uuid.uuid4()), salt='interview-invitation')
        except Exception as e:
            logger.error(f"Error generating invitation token: {str(e)}")
            raise InvitationError("Failed to generate invitation token", "TOKEN_GENERATION_ERROR")

    def create_bulk_invitations(self, interview_id: str, participants_data: List[Dict]) -> Dict[str, List]:
        """
        Creates multiple interview invitations and sends batch emails to participants.
        
        Args:
            interview_id: The ID of the interview
            participants_data: List of dictionaries containing participant information
        
        Returns:
            Dictionary containing lists of successful and failed invitations
        """
        successful_invitations = []
        failed_invitations = []
        invitations_data = []

        try:
            # First verify the interview exists
            interview = Interview.query.get(interview_id)
            if not interview:
                raise InvitationError("Interview not found", "INTERVIEW_NOT_FOUND")

            for participant_data in participants_data:
                try:
                    # Check if participant already has an invitation for this interview
                    participant = Participant.query.filter_by(email=participant_data['email']).first()
                    existing_invitation = None
                    
                    if participant:
                        existing_invitation = Invitation.query.filter_by(
                            participant_id=participant.participant_id,
                            interview_id=interview_id
                        ).first()

                    if existing_invitation:
                        failed_invitations.append({
                            'email': participant_data['email'],
                            'error': 'Participant already invited'
                        })
                        continue

                    # Create new participant if doesn't exist
                    if not participant:
                        participant = Participant(
                            participant_id=str(uuid.uuid4()),
                            email=participant_data['email'],
                            profession=participant_data.get('profession'),
                            interview_id=interview_id
                        )
                        db.session.add(participant)
                        db.session.flush()
                    
                    expiration_time = datetime.now(timezone.utc) + timedelta(days=7)    
                    
                    # Create new invitation
                    invitation = Invitation(
                        participant_id=participant.participant_id,
                        interview_id=interview_id,
                        invitation_token=self.generate_invitation_token(),
                        expires_at=expiration_time
                    )
                    db.session.add(invitation)
                    db.session.flush()

                    invitations_data.append({
                        'email': participant.email,
                        'invitation_token': invitation.invitation_token,
                        'interview_title': interview.title
                    })

                    successful_invitations.append({
                        'email': participant.email,
                        'token': invitation.invitation_token
                    })

                except Exception as e:
                    logger.error(f"Error creating invitation for {participant_data.get('email')}: {str(e)}")
                    failed_invitations.append({
                        'email': participant_data.get('email'),
                        'error': str(e)
                    })
                    continue

            if successful_invitations:
                db.session.commit()
                
                # Send batch emails
                email_results = current_app.email_service.send_batch_interview_invitations(invitations_data)

                # Update results based on email sending status
                for invitation in successful_invitations[:]:
                    if not email_results.get(invitation['email']):
                        successful_invitations.remove(invitation)
                        failed_invitations.append({
                            'email': invitation['email'],
                            'error': 'Failed to send invitation email'
                        })

            return {
                'successful': successful_invitations,
                'failed': failed_invitations
            }

        except Exception as e:
            db.session.rollback()
            logger.error(f"Error in bulk invitation creation: {str(e)}")
            raise InvitationError("Failed to create invitations", "BULK_INVITATION_ERROR")

    def verify_invitation(self, token: str) -> Optional[Invitation]:
        """
        Verify an invitation token and check if it's still valid.
        
        Args:
            token: The invitation token to verify
            
        Returns:
            Optional[Invitation]: The valid invitation if found and not expired, None otherwise
        """
        try:
            invitation = Invitation.query.filter_by(invitation_token=token).first()
            
            if not invitation:
                logger.warning(f"Invalid invitation token attempted: {token}")
                return None
                
            current_time = datetime.now(timezone.utc)
            
            # Ensure expiration time is timezone-aware for comparison
            if invitation.expires_at.tzinfo is None:
                invitation_expiry = invitation.expires_at.replace(tzinfo=timezone.utc)
            else:
                invitation_expiry = invitation.expires_at
                
            if current_time > invitation_expiry:
                logger.info(f"Expired invitation token attempted: {token}")
                return None
                
            return invitation
            
        except Exception as e:
            logger.error(f"Error verifying invitation: {str(e)}")
            return None
    
    def get_interview_invitations(self, interview_id: str) -> List[Invitation]:
        """Retrieve all invitations for a specific interview"""
        try:
            return Invitation.query.filter_by(interview_id=interview_id).all()
        except Exception as e:
            logger.error(f"Error retrieving invitations: {str(e)}")
            raise InvitationError("Failed to retrieve invitations", "INVITATION_FETCH_ERROR")

    def revoke_invitation(self, invitation_token: str) -> bool:
        """Revoke an existing invitation"""
        try:
            invitation = Invitation.query.filter_by(invitation_token=invitation_token).first()
            if invitation:
                db.session.delete(invitation)
                db.session.commit()
                logger.info(f"Invitation revoked successfully: {invitation_token}")
                return True
            return False
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error revoking invitation: {str(e)}")
            raise InvitationError("Failed to revoke invitation", "INVITATION_REVOKE_ERROR")