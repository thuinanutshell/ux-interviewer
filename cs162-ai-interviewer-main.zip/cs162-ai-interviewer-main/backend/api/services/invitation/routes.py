# backend/api/services/invitations/routes.py
from flask import Blueprint, request, jsonify, session, render_template, flash, redirect, url_for
from api.services.auth.routes import login_required
from .logic import InvitationService, InvitationError
from api.utils.email import EmailService
import logging
from api.services.interview.logic import InterviewService

logger = logging.getLogger(__name__)
invitation_bp = Blueprint('invitation_bp', __name__)
invitation_service = InvitationService()
interview_service = InterviewService()
invitation_bp = Blueprint('invitation_bp', __name__)

@invitation_bp.route('/bulk/<interview_id>', methods=['POST'])
@login_required
def create_bulk_invitations(interview_id):
    """Handle creation of multiple interview invitations."""
    try:
        data = request.get_json()
        participants_data = data.get('participants', [])
        
        results = invitation_service.create_bulk_invitations(
            interview_id=interview_id,
            participants_data=participants_data
        )
        
        return jsonify({
            'message': 'Invitations processed successfully',
            'results': {
                'successful': len(results['successful']),
                'failed': len(results['failed']),
                'details': results
            }
        }), 201
        
    except Exception as e:
        logger.error(f"Error processing bulk invitations: {str(e)}")
        return jsonify({
            'error': 'Failed to process invitations',
            'details': str(e)
        }), 500

@invitation_bp.route('/<interview_id>', methods=['GET'])
@login_required
def get_invitations(interview_id):
    """Retrieve all invitations for a specific interview."""
    try:
        invitations = invitation_service.get_interview_invitations(interview_id)
        return jsonify({
            'invitations': invitation_service.invitations_schema.dump(invitations)
        })
    except InvitationError as e:
        return jsonify({
            'error': str(e),
            'code': e.code
        }), 400
    except Exception as e:
        logger.error(f"Error retrieving invitations: {str(e)}")
        return jsonify({
            'error': 'Internal server error',
            'code': 'INTERNAL_ERROR'
        }), 500

@invitation_bp.route('/verify/<token>', methods=['GET'])
def verify_invitation(token):
    """Verify an invitation token."""
    try:
        invitation = invitation_service.verify_invitation(token)
        return jsonify({
            'valid': True,
            'invitation': invitation_service.invitation_schema.dump(invitation)
        })
    except InvitationError as e:
        return jsonify({
            'error': str(e),
            'code': e.code
        }), 400
    except Exception as e:
        logger.error(f"Error verifying invitation: {str(e)}")
        return jsonify({
            'error': 'Internal server error',
            'code': 'INTERNAL_ERROR'
        }), 500

@invitation_bp.route('/revoke/<token>', methods=['DELETE'])
@login_required
def revoke_invitation(token):
    """Revoke an existing invitation."""
    try:
        invitation_service.revoke_invitation(token)
        return jsonify({
            'message': 'Invitation revoked successfully'
        })
    except InvitationError as e:
        return jsonify({
            'error': str(e),
            'code': e.code
        }), 400
    except Exception as e:
        logger.error(f"Error revoking invitation: {str(e)}")
        return jsonify({
            'error': 'Internal server error',
            'code': 'INTERNAL_ERROR'
        }), 500

@invitation_bp.route('/manage/<interview_id>', methods=['GET'])
@login_required
def manage_participants(interview_id):
    """Display the participant management interface for an interview."""
    try:
        interview = interview_service.get_interview(interview_id, session['user_id'])
        participants = invitation_service.get_interview_invitations(interview_id)
        
        return render_template('invitation/manage.html',
                             interview=interview,
                             participants=participants)
    except Exception as e:
        logger.error(f"Error accessing participant management: {str(e)}")
        flash('Unable to access participant management', 'error')
        return redirect(url_for('interview_bp.portal', 
                              product_id=interview.product_id))