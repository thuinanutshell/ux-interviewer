from flask import Blueprint

invitation_bp = Blueprint('invitation', __name__, url_prefix='/invitation')

from . import routes