# backend/api/services/invitations/schemas.py
from marshmallow import Schema, fields, validate, ValidationError
from datetime import datetime, timedelta

class InvitationSchema(Schema):
    """Schema for validating and serializing interview invitations"""
    participant_id = fields.Str(dump_only=True)
    interview_id = fields.Str(required=True)
    email = fields.Email(required=True)
    profession = fields.Str(validate=validate.Length(max=255))
    invitation_token = fields.Str(dump_only=True)
    created_at = fields.DateTime(dump_only=True)
    expires_at = fields.DateTime(dump_only=True)

class ParticipantSchema(Schema):
    """Schema for validating and serializing participant information"""
    participant_id = fields.Str(dump_only=True)
    email = fields.Email(required=True)
    profession = fields.Str(validate=validate.Length(max=255))
    created_at = fields.DateTime(dump_only=True)