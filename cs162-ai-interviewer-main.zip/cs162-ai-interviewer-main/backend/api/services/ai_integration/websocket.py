# backend/api/services/ai_integration/websocket.py
from flask import current_app
from flask_socketio import emit
from . import socketio
from .logic import AIIntegrationService
import logging

logger = logging.getLogger(__name__)
ai_service = AIIntegrationService()

@socketio.on('connect')
def handle_connect():
    logger.info("Client connected to WebSocket")

@socketio.on('disconnect')
def handle_disconnect():
    logger.info("Client disconnected from WebSocket")

@socketio.on('user_response')
def handle_user_response(data):
    try:
        interview_id = data.get('interview_id')
        question = data.get('question_text')
        user_response = data.get('response_text')
        
        if not all([interview_id, question, user_response]):
            raise ValueError("Missing required data fields")
        
        result = ai_service.process_response(interview_id, question, user_response)
        emit('ai_response', result)
        
    except Exception as e:
        logger.error(f"Error processing user response: {str(e)}")
        emit('error', {'message': 'Failed to process response'})