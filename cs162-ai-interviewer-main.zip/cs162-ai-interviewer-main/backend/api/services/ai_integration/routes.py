# backend/api/services/ai_integration/routes.py
from flask import Blueprint, request, jsonify
from api.services.auth.routes import login_required
from .logic import AIIntegrationService
import logging

logger = logging.getLogger(__name__)
ai_integration_bp = Blueprint('ai_integration', __name__)
ai_service = AIIntegrationService()

@ai_integration_bp.route('/interview/<interview_id>/interact', methods=['POST'])
@login_required
def process_interaction(interview_id):
    """Process interview response and generate AI interaction"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No data provided'}), 400

        question_text = data.get('question_text')
        response_text = data.get('response_text')

        if not all([question_text, response_text]):
            return jsonify({
                'error': 'Missing required fields',
                'code': 'INVALID_REQUEST'
            }), 400

        product_context = data.get('product_context')
        result = ai_service.process_response(
            interview_id,
            question_text,
            response_text,
            follow_up_count=data.get('follow_up_count', 0),
            product_context=product_context
        )
        
        return jsonify(result)

    except Exception as e:
        logger.error(f"Error processing interaction: {str(e)}")
        return jsonify({
            'error': 'Failed to process interaction',
            'code': 'INTERACTION_ERROR'
        }), 500