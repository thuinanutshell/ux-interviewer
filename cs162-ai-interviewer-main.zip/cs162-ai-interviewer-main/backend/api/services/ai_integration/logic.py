# backend/api/services/ai_integration/logic.py
import logging
from typing import Dict
import google.generativeai as genai
from flask import current_app
from api.extensions import db
from api.models.agent import Conversation
from datetime import datetime

logger = logging.getLogger(__name__)

class AIIntegrationError(Exception):
    def __init__(self, message: str, code: str = None):
        super().__init__(message)
        self.code = code

class AIIntegrationService:
    _instance = None
    _initialized = False

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if not self._initialized:
            self._initialized = True
            self.model = None

    def initialize_gemini(self):
        """Initialize the Gemini API client"""
        if self.model is None:
            try:
                api_key = current_app.config.get('GEMINI_API_KEY')
                if not api_key:
                    raise AIIntegrationError("Gemini API key not configured", code="CONFIG_ERROR")
                genai.configure(api_key=api_key)
                self.model = genai.GenerativeModel('gemini-pro')
            except Exception as e:
                logger.error(f"Failed to initialize Gemini: {str(e)}")
                raise AIIntegrationError("Failed to initialize AI service", code="INIT_ERROR")
            
    def _generate_response(self, question: str, response: str, product_context: Dict = None) -> Dict:
        """Generate AI response using Gemini"""
        try:
            self.initialize_gemini()
            
            context = f"""Product: {product_context['name']}
            Category: {product_context['category']}
            Description: {product_context['description']}""" if product_context else "This is a user research interview."
            
            prompt = f"""As an AI interviewer conducting user research for a specific product, analyze this response and provide an insightful follow-up question.

            Context: {context}
            Original Question: {question}
            User's Response: {response}

            Generate a response that:
            1. References specific aspects of the product when acknowledging their answer
            2. Asks a targeted follow-up question related to the product context
            3. Maintains a professional yet engaging tone
            4. Avoids repetitive questioning patterns
            
            Focus on understanding the user's experience and perspective about this specific product."""

            ai_response = self.model.generate_content(prompt)
            
            return {
                'response': {
                    'text': ai_response.text.strip(),
                    'timestamp': datetime.utcnow().isoformat()
                }
            }

        except Exception as e:
            logger.error(f"Error generating response: {str(e)}")
            return {
                'response': {
                    'text': "I apologize, but I couldn't generate a follow-up question. Could you please elaborate on your previous response?",
                    'timestamp': datetime.utcnow().isoformat()
                }
            }
    def process_response(self, interview_id: str, question_text: str, response_text: str, follow_up_count: int = 0, product_context: Dict = None) -> Dict:
        """Process user response and generate AI interaction with follow-up tracking."""
        try:
            self.initialize_gemini()
            
            max_follow_ups = 2
            remaining_follow_ups = max_follow_ups - follow_up_count
            
            if follow_up_count >= max_follow_ups:
                return {
                    'success': True,
                    'response': {
                        'text': "Thank you for your detailed responses. Let's move on to the next question.",
                        'timestamp': datetime.utcnow().isoformat(),
                        'follow_up_complete': True
                    }
                }

            prompt = f"""You are conducting a user research interview. 
            This is follow-up question {follow_up_count + 1} of {max_follow_ups}.
            
            Original Question: {question_text}
            User Response: {response_text}

            Provide a follow-up that:
            1. Acknowledges their specific points
            2. Asks for elaboration on an interesting aspect
            3. Maintains a professional and engaging tone

            Keep your response focused and conversational."""

            ai_response = self.model.generate_content(prompt)
            response_text = ai_response.text.strip()

            # Save conversation with follow-up tracking
            conversation = Conversation(
                interview_id=interview_id,
                user_input=response_text,
                agent_response=response_text,
                is_follow_up=(follow_up_count > 0),
                follow_up_sequence=follow_up_count
            )
            db.session.add(conversation)
            db.session.commit()

            return {
                'success': True,
                'response': {
                    'text': response_text,
                    'conversation_id': conversation.conversation_id,
                    'timestamp': datetime.utcnow().isoformat(),
                    'follow_up_number': follow_up_count,
                    'remaining_follow_ups': remaining_follow_ups
                }
            }

        except Exception as e:
            logger.error(f"Error processing response: {str(e)}")
            db.session.rollback()
            return {
                'success': False,
                'error': str(e),
                'response': {
                    'text': "I couldn't process that response properly. Could you please elaborate on your answer?",
                    'timestamp': datetime.utcnow().isoformat()
                }
            }

    def _save_conversation(self, interview_id: str, user_input: str, ai_response: str) -> str:
        """Save conversation to database"""
        try:
            conversation = Conversation(
                interview_id=interview_id,
                user_input=user_input,
                agent_response=ai_response
            )
            db.session.add(conversation)
            db.session.commit()
            
            return conversation.conversation_id

        except Exception as e:
            logger.error(f"Error saving conversation: {str(e)}")
            db.session.rollback()
            raise AIIntegrationError("Failed to save conversation", code="DB_ERROR")

    def get_conversation_history(self, interview_id: str) -> list:
        """Retrieve conversation history for an interview"""
        try:
            conversations = Conversation.query.filter_by(interview_id=interview_id).order_by(Conversation.created_at).all()
            return [conv.to_dict() for conv in conversations]

        except Exception as e:
            logger.error(f"Error retrieving conversation history: {str(e)}")
            raise AIIntegrationError("Failed to retrieve conversation history", code="DB_ERROR")