# backend/api/services/ai_integration/__init__.py
from flask import Blueprint
from flask_socketio import SocketIO

ai_integration_bp = Blueprint('ai_integration', __name__)
socketio = SocketIO(cors_allowed_origins="*", async_mode='threading')

from . import routes
from . import websocket