from marshmallow import Schema, fields, EXCLUDE

class ConversationSchema(Schema):
    class Meta:
        unknown = EXCLUDE
    
    conversation_id = fields.String(dump_only=True)
    interview_id = fields.String(required=True)
    user_input = fields.String(required=True)
    agent_response = fields.String(required=True)
    created_at = fields.String(dump_only=True)