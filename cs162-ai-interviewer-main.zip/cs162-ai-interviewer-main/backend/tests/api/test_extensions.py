# backend/tests/api/test_extensions.py
import unittest
from flask import Flask, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager
from flask_marshmallow import Marshmallow
from flask_cors import CORS
from authlib.integrations.flask_client import OAuth
from flask_migrate import Migrate
from api.extensions import db, migrate, jwt, ma, cors, oauth


class TestExtensions(unittest.TestCase):
    def setUp(self):
        """
        Set up the Flask application for testing extensions.
        """
        self.app = Flask(__name__)
        self.app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        self.app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
        self.app.config['JWT_SECRET_KEY'] = 'test-secret-key'
        self.app.config['DEBUG'] = True

        # Initialize extensions with the Flask app
        db.init_app(self.app)
        migrate.init_app(self.app, db)
        jwt.init_app(self.app)
        ma.init_app(self.app)
        cors.init_app(self.app)
        oauth.init_app(self.app)

        # Create a test client
        self.client = self.app.test_client()

    def test_sqlalchemy_initialization(self):
        """
        Test that SQLAlchemy is initialized correctly.
        """
        with self.app.app_context():
            db.create_all()  # Ensure tables can be created without errors
            self.assertIsInstance(db, SQLAlchemy)

    def test_migrate_initialization(self):
        """
        Test that Flask-Migrate is initialized correctly.
        """
        self.assertIsInstance(migrate, Migrate)

    def test_jwt_initialization(self):
        """
        Test that JWTManager is initialized correctly and can create JWT tokens.
        """
        @self.app.route('/token')
        def token():
            from flask_jwt_extended import create_access_token
            access_token = create_access_token(identity="test-user")
            return jsonify(access_token=access_token)

        with self.app.test_request_context():
            response = self.client.get('/token')
            self.assertEqual(response.status_code, 200)
            self.assertIn('access_token', response.get_json())

    def test_marshmallow_initialization(self):
        """
        Test that Marshmallow is initialized correctly and can serialize data.
        """
        class TestSchema(ma.Schema):
            field = ma.Field()  # Corrected attribute access

        schema = TestSchema()
        result = schema.dump({"field": "value"})
        self.assertEqual(result, {"field": "value"})

    def test_cors_initialization(self):
        """
        Test that CORS is initialized correctly and allows cross-origin requests.
        """
        @self.app.route('/cors-test')
        def cors_test():
            return jsonify({"message": "CORS is working"})

        response = self.client.get('/cors-test', headers={"Origin": "http://example.com"})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json()["message"], "CORS is working")

    def test_oauth_initialization(self):
        """
        Test that OAuth is initialized correctly and can configure providers.
        """
        with self.app.app_context():
            oauth.register(
                name='test-provider',
                client_id='test-client-id',
                client_secret='test-client-secret',
                authorize_url='https://example.com/authorize',
                access_token_url='https://example.com/token',
                client_kwargs={'scope': 'profile email'}
            )
            self.assertIn('test-provider', oauth._clients)

    def test_sqlalchemy_context_management(self):
        """
        Test SQLAlchemy context management by creating and querying a test model.
        """
        class TestModel(db.Model):
            id = db.Column(db.Integer, primary_key=True)
            name = db.Column(db.String(80), nullable=False)

        with self.app.app_context():
            db.create_all()
            test_entry = TestModel(name="Test Entry")
            db.session.add(test_entry)
            db.session.commit()

            retrieved_entry = TestModel.query.filter_by(name="Test Entry").first()
            self.assertIsNotNone(retrieved_entry)
            self.assertEqual(retrieved_entry.name, "Test Entry")


if __name__ == "__main__":
    unittest.main()