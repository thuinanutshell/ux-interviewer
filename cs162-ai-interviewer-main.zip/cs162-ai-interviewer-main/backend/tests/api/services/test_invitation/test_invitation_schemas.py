# backend/tests/api/services/test_invitation/test_schemas.py
import unittest
from marshmallow.exceptions import ValidationError
from api.services.invitation.schemas import InvitationSchema, ParticipantSchema
from datetime import datetime, timezone


class TestInvitationSchema(unittest.TestCase):
    def setUp(self):
        """
        Set up schema instances for testing.
        """
        self.schema = InvitationSchema()

    def test_valid_invitation_serialization(self):
        """
        Test that valid invitation data is serialized correctly.
        """
        valid_data = {
            "participant_id": "participant123",
            "interview_id": "interview123",
            "email": "test@example.com",
            "profession": "Engineer",
            "invitation_token": "test-token",
            "created_at": datetime(2024, 1, 1, tzinfo=timezone.utc),
            "expires_at": datetime(2024, 1, 8, tzinfo=timezone.utc)
        }
        serialized_data = self.schema.dump(valid_data)
        self.assertEqual(serialized_data["participant_id"], "participant123")
        self.assertEqual(serialized_data["interview_id"], "interview123")
        self.assertEqual(serialized_data["email"], "test@example.com")
        self.assertEqual(serialized_data["profession"], "Engineer")
        self.assertEqual(serialized_data["invitation_token"], "test-token")
        self.assertEqual(serialized_data["created_at"], "2024-01-01T00:00:00+00:00")
        self.assertEqual(serialized_data["expires_at"], "2024-01-08T00:00:00+00:00")

    def test_valid_invitation_deserialization(self):
        """
        Test that valid invitation data is deserialized correctly.
        """
        valid_data = {
            "interview_id": "interview123",
            "email": "test@example.com",
            "profession": "Engineer"
        }
        deserialized_data = self.schema.load(valid_data)
        self.assertEqual(deserialized_data["interview_id"], "interview123")
        self.assertEqual(deserialized_data["email"], "test@example.com")
        self.assertEqual(deserialized_data["profession"], "Engineer")

    def test_missing_required_fields(self):
        """
        Test that missing required fields raise a ValidationError.
        """
        invalid_data = {
            "profession": "Engineer"
            # Missing interview_id and email
        }
        with self.assertRaises(ValidationError) as context:
            self.schema.load(invalid_data)
        self.assertIn("interview_id", context.exception.messages)
        self.assertIn("email", context.exception.messages)

    def test_invalid_email_format(self):
        """
        Test that an invalid email raises a ValidationError.
        """
        invalid_data = {
            "interview_id": "interview123",
            "email": "not-an-email",
            "profession": "Engineer"
        }
        with self.assertRaises(ValidationError) as context:
            self.schema.load(invalid_data)
        self.assertIn("email", context.exception.messages)

    def test_optional_profession(self):
        """
        Test that the profession field is optional.
        """
        valid_data = {
            "interview_id": "interview123",
            "email": "test@example.com"
        }
        deserialized_data = self.schema.load(valid_data)
        self.assertNotIn("profession", deserialized_data)

    def test_profession_length(self):
        """
        Test that a profession exceeding max length raises a ValidationError.
        """
        invalid_data = {
            "interview_id": "interview123",
            "email": "test@example.com",
            "profession": "a" * 256  # Exceeds max length of 255
        }
        with self.assertRaises(ValidationError) as context:
            self.schema.load(invalid_data)
        self.assertIn("profession", context.exception.messages)


class TestParticipantSchema(unittest.TestCase):
    def setUp(self):
        """
        Set up schema instances for testing.
        """
        self.schema = ParticipantSchema()

    def test_valid_participant_serialization(self):
        """
        Test that valid participant data is serialized correctly.
        """
        valid_data = {
            "participant_id": "participant123",
            "email": "test@example.com",
            "profession": "Engineer",
            "created_at": datetime(2024, 1, 1, tzinfo=timezone.utc)
        }
        serialized_data = self.schema.dump(valid_data)
        self.assertEqual(serialized_data["participant_id"], "participant123")
        self.assertEqual(serialized_data["email"], "test@example.com")
        self.assertEqual(serialized_data["profession"], "Engineer")
        self.assertEqual(serialized_data["created_at"], "2024-01-01T00:00:00+00:00")

    def test_valid_participant_deserialization(self):
        """
        Test that valid participant data is deserialized correctly.
        """
        valid_data = {
            "email": "test@example.com",
            "profession": "Engineer"
        }
        deserialized_data = self.schema.load(valid_data)
        self.assertEqual(deserialized_data["email"], "test@example.com")
        self.assertEqual(deserialized_data["profession"], "Engineer")

    def test_missing_email_field(self):
        """
        Test that missing the required 'email' field raises a ValidationError.
        """
        invalid_data = {"profession": "Engineer"}
        with self.assertRaises(ValidationError) as context:
            self.schema.load(invalid_data)
        self.assertIn("email", context.exception.messages)

    def test_invalid_email_format(self):
        """
        Test that an invalid email raises a ValidationError.
        """
        invalid_data = {"email": "not-an-email", "profession": "Engineer"}
        with self.assertRaises(ValidationError) as context:
            self.schema.load(invalid_data)
        self.assertIn("email", context.exception.messages)

    def test_profession_optional(self):
        """
        Test that the profession field is optional.
        """
        valid_data = {"email": "test@example.com"}
        deserialized_data = self.schema.load(valid_data)
        self.assertNotIn("profession", deserialized_data)

    def test_profession_length(self):
        """
        Test that a profession exceeding max length raises a ValidationError.
        """
        invalid_data = {
            "email": "test@example.com",
            "profession": "a" * 256  # Exceeds max length of 255
        }
        with self.assertRaises(ValidationError) as context:
            self.schema.load(invalid_data)
        self.assertIn("profession", context.exception.messages)


if __name__ == "__main__":
    unittest.main()
