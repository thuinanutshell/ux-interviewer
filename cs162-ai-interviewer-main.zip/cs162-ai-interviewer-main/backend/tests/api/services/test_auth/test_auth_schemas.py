# backend/tests/api/services/test_auth/test_schemas.py
import unittest
from marshmallow.exceptions import ValidationError
from api.services.auth.schemas import LoginSchema, RegistrationSchema, UserSchema
from datetime import datetime

class TestLoginSchema(unittest.TestCase):
    def setUp(self):
        """
        Set up schema instances for testing.
        """
        self.login_schema = LoginSchema()

    def test_valid_login_data(self):
        """
        Test that valid login data is validated successfully.
        """
        valid_data = {"identifier": "testuser", "password": "ValidPassword123"}
        validated_data = self.login_schema.load(valid_data)
        self.assertEqual(validated_data["identifier"], "testuser")
        self.assertEqual(validated_data["password"], "ValidPassword123")

    def test_invalid_login_identifier(self):
        """
        Test that invalid identifier raises a ValidationError.
        """
        invalid_data = {"identifier": "a", "password": "ValidPassword123"}
        with self.assertRaises(ValidationError) as context:
            self.login_schema.load(invalid_data)
        self.assertIn("identifier", context.exception.messages)

    def test_invalid_login_password(self):
        """
        Test that a password less than 8 characters raises a ValidationError.
        """
        invalid_data = {"identifier": "testuser", "password": "short"}
        with self.assertRaises(ValidationError) as context:
            self.login_schema.load(invalid_data)
        self.assertIn("password", context.exception.messages)

class TestRegistrationSchema(unittest.TestCase):
    def setUp(self):
        """
        Set up schema instances for testing.
        """
        self.registration_schema = RegistrationSchema()

    def test_valid_registration_data(self):
        """
        Test that valid registration data is validated successfully.
        """
        valid_data = {
            "username": "testuser",
            "email": "test@example.com",
            "password": "ValidPassword123"
        }
        validated_data = self.registration_schema.load(valid_data)
        self.assertEqual(validated_data["username"], "testuser")
        self.assertEqual(validated_data["email"], "test@example.com")
        self.assertEqual(validated_data["password"], "ValidPassword123")

    def test_invalid_username_length(self):
        """
        Test that a username less than 3 characters raises a ValidationError.
        """
        invalid_data = {
            "username": "ab",
            "email": "test@example.com",
            "password": "ValidPassword123"
        }
        with self.assertRaises(ValidationError) as context:
            self.registration_schema.load(invalid_data)
        self.assertIn("username", context.exception.messages)

    def test_invalid_username_characters(self):
        """
        Test that a username with invalid characters raises a ValidationError.
        """
        invalid_data = {
            "username": "invalid@username",
            "email": "test@example.com",
            "password": "ValidPassword123"
        }
        with self.assertRaises(ValidationError) as context:
            self.registration_schema.load(invalid_data)
        self.assertIn("username", context.exception.messages)

    def test_invalid_email(self):
        """
        Test that an invalid email raises a ValidationError.
        """
        invalid_data = {
            "username": "testuser",
            "email": "not-an-email",
            "password": "ValidPassword123"
        }
        with self.assertRaises(ValidationError) as context:
            self.registration_schema.load(invalid_data)
        self.assertIn("email", context.exception.messages)

    def test_invalid_password_length(self):
        """
        Test that a password less than 8 characters raises a ValidationError.
        """
        invalid_data = {
            "username": "testuser",
            "email": "test@example.com",
            "password": "Short1"
        }
        with self.assertRaises(ValidationError) as context:
            self.registration_schema.load(invalid_data)
        self.assertIn("password", context.exception.messages)

    def test_invalid_password_format(self):
        """
        Test that a password without uppercase, lowercase, and numbers raises a ValidationError.
        """
        invalid_data = {
            "username": "testuser",
            "email": "test@example.com",
            "password": "invalidpassword"
        }
        with self.assertRaises(ValidationError) as context:
            self.registration_schema.load(invalid_data)
        self.assertIn("password", context.exception.messages)

class TestUserSchema(unittest.TestCase):
    def setUp(self):
        """
        Set up schema instances for testing.
        """
        self.user_schema = UserSchema()

    def test_valid_user_serialization(self):
        """
        Test that valid user data is serialized correctly.
        """
        user_data = {
            "username": "testuser",
            "email": "test@example.com",
            "created_at": datetime(2024, 1, 1, 12, 0, 0),
            "last_login": datetime(2024, 1, 2, 12, 0, 0),
            "is_oauth_user": False
        }
        serialized_data = self.user_schema.dump(user_data)
        self.assertEqual(serialized_data["username"], "testuser")
        self.assertEqual(serialized_data["email"], "test@example.com")
        self.assertEqual(serialized_data["created_at"], "2024-01-01 12:00:00")
        self.assertEqual(serialized_data["last_login"], "2024-01-02 12:00:00")
        self.assertFalse(serialized_data["is_oauth_user"])

    def test_partial_user_serialization(self):
        """
        Test that missing optional fields are handled gracefully during serialization.
        """
        user_data = {
            "username": "testuser",
            "email": "test@example.com"
        }
        serialized_data = self.user_schema.dump(user_data)
        self.assertEqual(serialized_data["username"], "testuser")
        self.assertEqual(serialized_data["email"], "test@example.com")
        self.assertNotIn("created_at", serialized_data)
        self.assertNotIn("last_login", serialized_data)
        self.assertNotIn("is_oauth_user", serialized_data)

    def test_user_deserialization(self):
        """
        Test that valid user data is deserialized into a User instance.
        """
        input_data = {
            "username": "testuser",
            "email": "test@example.com",
            "is_oauth_user": False
        }
        user_instance = self.user_schema.load(input_data)
        self.assertEqual(user_instance.username, "testuser")
        self.assertEqual(user_instance.email, "test@example.com")
        self.assertFalse(user_instance.is_oauth_user)


if __name__ == "__main__":
    unittest.main()
