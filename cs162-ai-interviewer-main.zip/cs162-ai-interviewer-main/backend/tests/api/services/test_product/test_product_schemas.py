# backend/tests/api/services/test_product/test_product_schemas.py
import unittest
from api.services.product.schemas import ProductUpdateSchema

class TestProductUpdateSchema(unittest.TestCase):
    def setUp(self):
        self.schema = ProductUpdateSchema()

    def test_valid_product_update_partial(self):
        """
        Test that partial updates are allowed.
        """
        valid_data = {
            "product_name": "Updated Product"
        }
        deserialized_data = self.schema.load(valid_data, partial=True)
        self.assertEqual(deserialized_data["product_name"], "Updated Product")
        self.assertNotIn("product_url", deserialized_data)

if __name__ == "__main__":
    unittest.main()