import unittest
from unittest.mock import patch, MagicMock
from flask import Flask
from flask_socketio import SocketIO, emit
from api.services.ai_integration.websocket import handle_connect, handle_disconnect, handle_user_response


class TestWebSocketHandlers(unittest.TestCase):
    def setUp(self):
        """
        Set up the Flask application and SocketIO test client.
        """
        self.app = Flask(__name__)
        self.app.config['TESTING'] = True
        self.app.config['SECRET_KEY'] = 'test-secret-key'
        self.socketio = SocketIO(self.app, cors_allowed_origins="*")
        self.client = self.socketio.test_client(self.app)

        # Register WebSocket event handlers
        self.socketio.on_event('connect', handle_connect)
        self.socketio.on_event('disconnect', handle_disconnect)
        self.socketio.on_event('user_response', handle_user_response)

    def test_handle_connect(self):
        """
        Test that the WebSocket 'connect' event is handled correctly.
        """
        with patch('api.services.ai_integration.websocket.logger') as mock_logger:
            self.client.emit('connect')
            self.assertTrue(self.client.is_connected())
            mock_logger.info.assert_called_once_with("Client connected to WebSocket")

    def test_handle_disconnect(self):
        """
        Test that the WebSocket 'disconnect' event is handled correctly.
        """
        with patch('api.services.ai_integration.websocket.logger') as mock_logger:
            self.client.disconnect()
            self.assertFalse(self.client.is_connected())
            mock_logger.info.assert_called_once_with("Client disconnected from WebSocket")

    @patch('api.services.ai_integration.websocket.ai_service.process_response')
    def test_handle_user_response_success(self, mock_process_response):
        """
        Test successful handling of the 'user_response' WebSocket event.
        """
        mock_process_response.return_value = {
            'success': True,
            'response': {
                'text': "This is a follow-up question.",
                'timestamp': "2024-01-01T00:00:00Z"
            }
        }

        data = {
            'interview_id': '12345',
            'question_text': 'What do you think about remote work?',
            'response_text': 'I think it is great.'
        }

        self.client.emit('user_response', data)
        received = self.client.get_received()

        self.assertEqual(len(received), 1)
        self.assertEqual(received[0]['name'], 'ai_response')
        self.assertTrue(received[0]['args'][0]['success'])
        self.assertEqual(received[0]['args'][0]['response']['text'], "This is a follow-up question.")

    def test_handle_user_response_missing_data(self):
        """
        Test handling of 'user_response' WebSocket event with missing data.
        """
        with patch('api.services.ai_integration.websocket.emit') as mock_emit:
            data = {
                'question_text': 'What do you think about remote work?',
                # Missing 'interview_id' and 'response_text'
            }

            handle_user_response(data)
            mock_emit.assert_called_once_with('error', {'message': 'Failed to process response'})

    @patch('api.services.ai_integration.websocket.ai_service.process_response', side_effect=Exception("Processing error"))
    @patch('api.services.ai_integration.websocket.logger')
    def test_handle_user_response_processing_error(self, mock_logger, mock_process_response):
        """
        Test error handling during processing of the 'user_response' WebSocket event.
        """
        with patch('api.services.ai_integration.websocket.emit') as mock_emit:
            data = {
                'interview_id': '12345',
                'question_text': 'What do you think about remote work?',
                'response_text': 'I think it is great.'
            }

            handle_user_response(data)
            mock_logger.error.assert_called_once_with("Error processing user response: Processing error")
            mock_emit.assert_called_once_with('error', {'message': 'Failed to process response'})

    def test_handle_user_response_invalid_json(self):
        """
        Test handling of 'user_response' event with invalid JSON.
        """
        with patch('api.services.ai_integration.websocket.emit') as mock_emit:
            handle_user_response(None)  # Simulate invalid input
            mock_emit.assert_called_once_with('error', {'message': 'Failed to process response'})


if __name__ == "__main__":
    unittest.main()