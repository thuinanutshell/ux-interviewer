import unittest
from unittest.mock import patch, MagicMock
from api.services.ai_integration.logic import AIIntegrationService, AIIntegrationError
from api.models.agent import Conversation
from api.extensions import db
from datetime import datetime, timezone
import uuid
from run import create_app 
from tests.conftest import TestConfig  


class TestAIIntegrationService(unittest.TestCase):
    def setUp(self):
        """
        Set up the test database and application context.
        """
        self.app = create_app(TestConfig)
        self.ctx = self.app.app_context()
        self.ctx.push()
        db.create_all()

        self.service = AIIntegrationService()

    def tearDown(self):
        """
        Tear down the database and application context.
        """
        db.session.remove()
        db.drop_all()
        self.ctx.pop()


    @patch('api.services.ai_integration.logic.genai')
    def test_generate_response_success(self, mock_genai):
        """
        Test successful generation of AI response using Gemini.
        """
        self.service.model = MagicMock()
        mock_response = MagicMock()
        mock_response.text = "This is a follow-up question."
        self.service.model.generate_content.return_value = mock_response

        response = self.service._generate_response("What is your opinion?", "I like it.")

        self.assertEqual(response['response']['text'], "This is a follow-up question.")
        self.assertIn("timestamp", response['response'])

    def test_generate_response_failure(self):
        """
        Test fallback response when AI response generation fails.
        """
        self.service.model = None  # Simulate uninitialized model
        response = self.service._generate_response("What is your opinion?", "I like it.")

        self.assertEqual(
            response['response']['text'],
            "I apologize, but I couldn't generate a follow-up question. Could you please elaborate on your previous response?"
        )
        self.assertIn("timestamp", response['response'])

    @patch('api.services.ai_integration.logic.AIIntegrationService._generate_response')
    def test_process_response_success(self, mock_generate_response):
        """
        Test processing a user response successfully with follow-up tracking.
        """
        mock_generate_response.return_value = {
            'response': {'text': "This is a follow-up question.", 'timestamp': datetime.now(timezone.utc).isoformat()}
        }
        response = self.service.process_response(
            interview_id=str(uuid.uuid4()),
            question_text="What is your opinion?",
            response_text="I like it.",
            follow_up_count=1
        )

        self.assertTrue(response['success'])
        self.assertEqual(response['response']['text'], "This is a follow-up question.")
        self.assertEqual(response['response']['follow_up_number'], 1)
        self.assertEqual(response['response']['remaining_follow_ups'], 1)

    def test_process_response_follow_up_complete(self):
        """
        Test that follow-ups stop after reaching the maximum allowed count.
        """
        response = self.service.process_response(
            interview_id=str(uuid.uuid4()),
            question_text="What is your opinion?",
            response_text="I like it.",
            follow_up_count=2  # Maximum follow-ups reached
        )

        self.assertTrue(response['success'])
        self.assertTrue(response['response']['follow_up_complete'])
        self.assertEqual(
            response['response']['text'],
            "Thank you for your detailed responses. Let's move on to the next question."
        )


    @patch('api.services.ai_integration.logic.db.session.commit', side_effect=Exception("DB Error"))
    def test_save_conversation_failure(self, mock_commit):
        """
        Test failure when saving a conversation to the database.
        """
        with self.assertRaises(AIIntegrationError) as context:
            self.service._save_conversation(
                interview_id=str(uuid.uuid4()),
                user_input="This is a user input.",
                ai_response="This is an AI response."
            )
        self.assertEqual(context.exception.code, "DB_ERROR")
        self.assertEqual(str(context.exception), "Failed to save conversation")

    @patch('api.services.ai_integration.logic.Conversation.query')
    def test_get_conversation_history_success(self, mock_query):
        """
        Test retrieving conversation history successfully.
        """
        mock_query.filter_by.return_value.order_by.return_value.all.return_value = [
            MagicMock(to_dict=lambda: {"conversation_id": "1", "user_input": "Hi", "agent_response": "Hello"}),
            MagicMock(to_dict=lambda: {"conversation_id": "2", "user_input": "How are you?", "agent_response": "I am fine"})
        ]
        history = self.service.get_conversation_history(interview_id="12345")
        self.assertEqual(len(history), 2)
        self.assertEqual(history[0]['user_input'], "Hi")
        self.assertEqual(history[1]['user_input'], "How are you?")


if __name__ == "__main__":
    unittest.main()