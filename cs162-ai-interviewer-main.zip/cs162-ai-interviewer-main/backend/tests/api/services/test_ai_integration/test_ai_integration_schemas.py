# backend/tests/api/services/test_ai_integration/test_schemas.py
import unittest
from marshmallow.exceptions import ValidationError
from api.services.ai_integration.schemas import ConversationSchema


class TestConversationSchema(unittest.TestCase):
    def setUp(self):
        """
        Set up the schema instance for testing.
        """
        self.schema = ConversationSchema()

    def test_valid_data_serialization(self):
        """
        Test that valid input data is serialized correctly.
        """
        valid_data = {
            "conversation_id": "123",
            "interview_id": "456",
            "user_input": "What do you think about remote work?",
            "agent_response": "I believe remote work has its pros and cons.",
            "created_at": "2024-01-01T00:00:00Z"
        }

        serialized_data = self.schema.dump(valid_data)

        self.assertEqual(serialized_data["conversation_id"], "123")
        self.assertEqual(serialized_data["interview_id"], "456")
        self.assertEqual(serialized_data["user_input"], "What do you think about remote work?")
        self.assertEqual(serialized_data["agent_response"], "I believe remote work has its pros and cons.")
        self.assertEqual(serialized_data["created_at"], "2024-01-01T00:00:00Z")

    def test_valid_data_deserialization(self):
        """
        Test that valid input data is deserialized correctly.
        """
        valid_data = {
            "interview_id": "456",
            "user_input": "What do you think about remote work?",
            "agent_response": "I believe remote work has its pros and cons."
        }

        deserialized_data = self.schema.load(valid_data)

        self.assertEqual(deserialized_data["interview_id"], "456")
        self.assertEqual(deserialized_data["user_input"], "What do you think about remote work?")
        self.assertEqual(deserialized_data["agent_response"], "I believe remote work has its pros and cons.")

    def test_missing_required_fields(self):
        """
        Test that missing required fields raises a ValidationError.
        """
        invalid_data = {
            "user_input": "What do you think about remote work?",
            "agent_response": "I believe remote work has its pros and cons."
            # Missing 'interview_id'
        }

        with self.assertRaises(ValidationError) as context:
            self.schema.load(invalid_data)

        self.assertIn("interview_id", context.exception.messages)

    def test_extra_fields_excluded(self):
        """
        Test that extra fields in input data are excluded during deserialization.
        """
        data_with_extra_fields = {
            "interview_id": "456",
            "user_input": "What do you think about remote work?",
            "agent_response": "I believe remote work has its pros and cons.",
            "extra_field": "This should not be included"
        }

        deserialized_data = self.schema.load(data_with_extra_fields)

        self.assertNotIn("extra_field", deserialized_data)

    def test_invalid_field_types(self):
        """
        Test that invalid field types raise a ValidationError.
        """
        invalid_data = {
            "interview_id": 456,  # Should be a string
            "user_input": "What do you think about remote work?",
            "agent_response": ["This should be a string, not a list"]  # Invalid type
        }

        with self.assertRaises(ValidationError) as context:
            self.schema.load(invalid_data)

        self.assertIn("interview_id", context.exception.messages)
        self.assertIn("agent_response", context.exception.messages)

    def test_dump_only_fields_exclusion(self):
        """
        Test that dump-only fields are excluded during deserialization.
        """
        input_data = {
            "conversation_id": "123",  # Dump-only field
            "interview_id": "456",
            "user_input": "What do you think about remote work?",
            "agent_response": "I believe remote work has its pros and cons."
        }

        deserialized_data = self.schema.load(input_data)

        self.assertNotIn("conversation_id", deserialized_data)

    def test_partial_loading(self):
        """
        Test partial loading where only some required fields are provided.
        """
        partial_data = {
            "interview_id": "456",
            "user_input": "What do you think about remote work?"
        }

        with self.assertRaises(ValidationError) as context:
            self.schema.load(partial_data)

        self.assertIn("agent_response", context.exception.messages)

    def test_empty_input(self):
        """
        Test that an empty input raises a ValidationError.
        """
        with self.assertRaises(ValidationError) as context:
            self.schema.load({})

        self.assertIn("interview_id", context.exception.messages)
        self.assertIn("user_input", context.exception.messages)
        self.assertIn("agent_response", context.exception.messages)

    def test_dump_with_missing_dump_only_fields(self):
        """
        Test dumping data where dump-only fields are missing.
        """
        input_data = {
            "interview_id": "456",
            "user_input": "What do you think about remote work?",
            "agent_response": "I believe remote work has its pros and cons."
            # 'conversation_id' and 'created_at' are missing
        }

        serialized_data = self.schema.dump(input_data)

        self.assertEqual(serialized_data["interview_id"], "456")
        self.assertEqual(serialized_data["user_input"], "What do you think about remote work?")
        self.assertEqual(serialized_data["agent_response"], "I believe remote work has its pros and cons.")
        self.assertNotIn("conversation_id", serialized_data)
        self.assertNotIn("created_at", serialized_data)


if __name__ == "__main__":
    unittest.main()
