import unittest
from unittest.mock import patch, MagicMock
from flask import Flask
from api.services.analytics.logic import AnalyticsService, AnalyticsError
from collections import Counter


class TestAnalyticsService(unittest.TestCase):
    def setUp(self):
        """
        Set up the AnalyticsService instance and application context.
        """
        self.app = Flask(__name__)
        self.app.config['TESTING'] = True
        self.app.config['SECRET_KEY'] = 'test-secret-key'
        self.app.config['GEMINI_API_KEY'] = 'test-api-key'
        self.ctx = self.app.app_context()
        self.ctx.push()
        self.service = AnalyticsService()

    def tearDown(self):
        """
        Tear down the application context.
        """
        self.ctx.pop()


    @patch('api.services.analytics.logic.genai')
    def test_get_themes_success(self, mock_genai):
        """
        Test successful extraction of themes.
        """
        self.service.model = MagicMock()
        mock_response = MagicMock()
        mock_response.text = "theme1, theme2, theme3"
        self.service.model.generate_content.return_value = mock_response

        themes = self.service._get_themes("Some interview content")
        self.assertEqual(themes, ["theme1", "theme2", "theme3"])

    @patch('api.services.analytics.logic.genai')
    def test_get_sentiment_success(self, mock_genai):
        """
        Test successful sentiment analysis.
        """
        self.service.model = MagicMock()
        mock_response = MagicMock()
        mock_response.text = "0.8\nGenerally positive with a few concerns"
        self.service.model.generate_content.return_value = mock_response

        sentiment = self.service._get_sentiment("Some interview content")
        self.assertEqual(sentiment["overall"]["score"], 0.8)
        self.assertEqual(sentiment["overall"]["explanation"], "Generally positive with a few concerns")

    def test_get_sentiment_fallback(self):
        """
        Test fallback sentiment analysis when the response format is invalid.
        """
        self.service.model = MagicMock()
        mock_response = MagicMock()
        mock_response.text = "Invalid response"
        self.service.model.generate_content.return_value = mock_response

        sentiment = self.service._get_sentiment("Some interview content")
        self.assertEqual(sentiment["overall"]["score"], 0.5)
        self.assertEqual(sentiment["overall"]["explanation"], "Sentiment analysis completed")

    @patch('api.services.analytics.logic.genai')
    def test_get_summary_success(self, mock_genai):
        """
        Test successful summary generation.
        """
        self.service.model = MagicMock()
        mock_response = MagicMock()
        mock_response.text = "This is a summary of the interview content."
        self.service.model.generate_content.return_value = mock_response

        summary = self.service._get_summary("Some interview content")
        self.assertEqual(summary, "This is a summary of the interview content.")

    @patch('api.services.analytics.logic.AnalyticsService.initialize_gemini')
    @patch('api.services.analytics.logic.AnalyticsService._get_themes')
    @patch('api.services.analytics.logic.AnalyticsService._get_sentiment')
    @patch('api.services.analytics.logic.AnalyticsService._get_summary')
    def test_analyze_interview_responses_success(
        self, mock_summary, mock_sentiment, mock_themes, mock_initialize_gemini
    ):
        """
        Test successful analysis of interview responses.
        """
        mock_themes.return_value = ["theme1", "theme2"]
        mock_sentiment.return_value = {
            "overall": {
                "score": 0.8,
                "explanation": "Generally positive"
            }
        }
        mock_summary.return_value = "This is a summary."

        responses = {
            "q1": ["Response 1", "Response 2"],
            "q2": ["Response 3"]
        }
        questions = [
            {"question_id": "q1", "question": "What do you think?"},
            {"question_id": "q2", "question": "Why do you think that?"}
        ]

        result = self.service.analyze_interview_responses("12345", responses, questions)

        self.assertEqual(result["key_themes"], ["theme1", "theme2"])
        self.assertEqual(result["sentiment"]["overall"]["score"], 0.8)
        self.assertEqual(result["summary"], "This is a summary.")

    @patch('api.services.analytics.logic.logger.warning')
    def test_analyze_interview_responses_fallback(self, mock_logger):
        """
        Test fallback analysis when Gemini fails.
        """
        responses = {
            "q1": ["Response 1", "Response 2"],
            "q2": ["Response 3"]
        }
        questions = [
            {"question_id": "q1", "question": "What do you think?"},
            {"question_id": "q2", "question": "Why do you think that?"}
        ]

        with patch.object(self.service, 'initialize_gemini', side_effect=Exception("Gemini failure")):
            result = self.service.analyze_interview_responses("12345", responses, questions)

        self.assertIn("key_themes", result)
        self.assertIn("sentiment", result)
        self.assertIn("summary", result)
        mock_logger.assert_called_once_with("Gemini analysis failed, using fallback: Gemini failure")

    def test_fallback_analysis(self):
        """
        Test the fallback analysis method.
        """
        formatted_data = [
            {"question": "What do you think?", "responses": ["Response 1", "Response 2"]},
            {"question": "Why do you think that?", "responses": ["Response 3"]}
        ]

        result = self.service._fallback_analysis(formatted_data)

        self.assertIn("key_themes", result)
        self.assertIn("sentiment", result)
        self.assertIn("summary", result)
        self.assertEqual(result["sentiment"]["overall"]["explanation"], "Basic sentiment analysis based on keyword frequency")


if __name__ == "__main__":
    unittest.main()