# backend/tests/api/services/test_analytics/test_analytics_schemas.py
import unittest
from marshmallow.exceptions import ValidationError
from api.services.analytics.schemas import AnalysisResultSchema


class TestAnalysisResultSchema(unittest.TestCase):
    def setUp(self):
        """
        Set up the schema instance for testing.
        """
        self.schema = AnalysisResultSchema()

    def test_missing_fields(self):
        """
        Test that missing fields in the data do not raise errors during serialization.
        """
        partial_data = {
            "interview_id": "12345",
            "key_themes": ["theme1", "theme2"]
            # Missing sentiment and summary fields
        }

        serialized_data = self.schema.dump(partial_data)

        self.assertEqual(serialized_data["interview_id"], "12345")
        self.assertEqual(serialized_data["key_themes"], ["theme1", "theme2"])
        self.assertNotIn("sentiment", serialized_data)
        self.assertNotIn("summary", serialized_data)

    def test_load_dump_only_fields(self):
        """
        Test that dump-only fields cannot be loaded.
        """
        input_data = {
            "interview_id": "12345",  # Dump-only field
            "key_themes": ["theme1", "theme2"],  # Dump-only field
            "sentiment": {
                "overall": 0.8,
                "explanation": "Positive sentiment"
            },  # Dump-only field
            "summary": "This is a summary."  # Dump-only field
        }

        with self.assertRaises(ValidationError):
            self.schema.load(input_data)

    def test_partial_loading(self):
        """
        Test partial loading of data (not allowed for dump-only schema).
        """
        partial_data = {
            "key_themes": ["theme1", "theme2"]
        }

        with self.assertRaises(ValidationError):
            self.schema.load(partial_data)


if __name__ == "__main__":
    unittest.main()