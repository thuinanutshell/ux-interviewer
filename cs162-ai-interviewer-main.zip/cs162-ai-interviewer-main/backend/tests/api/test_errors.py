# backend/tests/api/test_errors.py
import unittest
from flask import Flask, jsonify
from api.errors import handle_404, handle_500


class TestErrorHandlers(unittest.TestCase):
    def setUp(self):
        """
        Set up the Flask application for testing error handlers.
        """
        self.app = Flask(__name__)
        self.client = self.app.test_client()

        # Add error handlers to the Flask app
        self.app.register_error_handler(404, handle_404)
        self.app.register_error_handler(500, handle_500)

    def test_handle_404(self):
        """
        Test the 404 error handler.
        """
        with self.app.test_request_context('/nonexistent'):
            response = handle_404(Exception("Page not found"))
            self.assertEqual(response.status_code, 404)
            self.assertIn("Resource not found", response.get_json()["error"])
            self.assertIn("Page not found", response.get_json()["message"])

    def test_handle_500(self):
        """
        Test the 500 error handler.
        """
        with self.app.test_request_context('/cause-error'):
            response = handle_500(Exception("Unexpected error"))
            self.assertEqual(response.status_code, 500)
            self.assertIn("Internal server error", response.get_json()["error"])
            self.assertIn("Unexpected error", response.get_json()["message"])

    def test_404_flask_integration(self):
        """
        Test Flask integration with the 404 error handler.
        """
        @self.app.route('/existent')
        def existent_route():
            return jsonify({"message": "This route exists"}), 200

        response = self.client.get('/nonexistent')
        self.assertEqual(response.status_code, 404)
        self.assertIn("Resource not found", response.get_json()["error"])

    def test_500_flask_integration(self):
        """
        Test Flask integration with the 500 error handler.
        """
        @self.app.route('/error')
        def error_route():
            raise Exception("Unexpected error in route")

        response = self.client.get('/error')
        self.assertEqual(response.status_code, 500)
        self.assertIn("Internal server error", response.get_json()["error"])


if __name__ == "__main__":
    unittest.main()
