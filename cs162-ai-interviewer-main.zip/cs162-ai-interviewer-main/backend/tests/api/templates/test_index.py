import unittest
from run import app
from flask import session

class IndexTemplateTestCase(unittest.TestCase):
    """Tests for the index.html template."""

    def setUp(self):
        app.testing = True
        self.client = app.test_client()

    def test_index_page_guest_user(self):
        """Test the index page for a guest user."""
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Welcome to AI Interviewer", response.data)
        self.assertIn(b"Improve your product by talking to users!", response.data)
        self.assertNotIn(b"Go to Profile", response.data)

    def test_index_page_logged_in_user(self):
        """Test the index page for a logged-in user."""
        with self.client.session_transaction() as session:
            session["user_id"] = "123"  # Mock a logged-in user
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Welcome back! Ready for your next interview practice?", response.data)
        self.assertIn(b"Go to Profile", response.data)
        self.assertNotIn(b"Improve your product by talking to users!", response.data)

if __name__ == "__main__":
    unittest.main()
