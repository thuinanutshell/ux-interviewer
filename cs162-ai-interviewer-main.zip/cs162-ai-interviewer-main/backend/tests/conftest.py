# backend/tests/conftest.py
import unittest
from api import create_app
from api.extensions import db
from config import Config

class TestConfig(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    SECRET_KEY = "test-secret-key" 
    SERVER_NAME = "localhost"

class BaseTestCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        """
        Set up the test app once for the test suite.
        """
        cls.app = create_app(TestConfig)
        cls.client = cls.app.test_client()
        with cls.app.app_context():
            db.create_all()

    @classmethod
    def tearDownClass(cls):
        """
        Tear down the app and database after the test suite.
        """
        with cls.app.app_context():
            db.session.remove()
            db.drop_all()

    def setUp(self):
        """
        Run before each test. Opens a new database transaction.
        """
        self.ctx = self.app.app_context()
        self.ctx.push()

    def tearDown(self):
        """
        Run after each test. Rolls back the transaction to maintain isolation.
        """
        self.ctx.pop()
